# Research Intelligence Brief

## Energy-Shock Transmission: Risk Appetite and Second-Round Triggers

**Thesis:** An energy shock should be governed through a transmission matrix, not a single headline trigger.

**Verified numeric findings:**
- Headline acceleration: **0.2 percentage points**.
- Energy–services gap: **17.5 percentage points**.
- Energy–core gap: **18.3 percentage points**.

**Decision matrix:** If the observed divergence persists, validate exposures and stress the relevant risk appetite or valuation assumptions; if it reverses, downgrade the signal. Competing explanations include classification and timing effects.

**What would change our mind?** Subsequent official revisions or entity-level data that contradict the proposed channel.

**Practical consequence:** Monitor the next source release and independently validate any entity-specific transmission.

**Limitations:** These are macroeconomic observations, not bank-specific risk-appetite breaches.

Source: https://ec.europa.eu/eurostat/web/products/euro-indicators/w/2-04112026-ap
