# Methodology — Energy-Shock Transmission: Risk Appetite and Second-Round Triggers

## Source and provenance
https://ec.europa.eu/eurostat/web/products/euro-indicators/w/2-04112026-ap

All 5 observations are directly transcribed from the cited official statistics as displayed on 5 November 2026. Periods, scope and units appear in data.json.

## Calculations
- **Headline acceleration:** 0.2 percentage points (recompute from data.json; no hidden imputation).
- **Energy–services gap:** 17.5 percentage points (recompute from data.json; no hidden imputation).
- **Energy–core gap:** 18.3 percentage points (recompute from data.json; no hidden imputation).

## Interpretation constraints
These are macroeconomic observations, not bank-specific risk-appetite breaches.

No statistical significance, causal identification, regression, or backtest is claimed.

## Interactive hypothetical scenario
`shock_percent * exposed_share_percent / 100`; the controls range 0–15% and 0–100%. Sensitivity and monotonicity checks are provided in the delivery audit.
