# Energy-Shock Transmission: Risk Appetite and Second-Round Triggers

**Category:** Risk & Governance Intelligence
**Date:** 2026-11-05
**Status:** Review before publishing

An energy shock should be governed through a transmission matrix, not a single headline trigger.

Source: https://ec.europa.eu/eurostat/web/products/euro-indicators/w/2-04112026-ap

The dashboard uses original source observations and a separate hypothetical sensitivity laboratory. It does not claim causality or forecast skill.

See `methodology.md`, `executive-brief.md`, and `data.json`.
