# Norway Retail Volume versus Turnover: The Price-Mix Illusion

**Category:** Business & Economic Intelligence
**Date:** 2026-11-05
**Status:** Review before publishing

A positive aggregate trade reading can conceal a flat retail-volume channel.

Source: https://www.ssb.no/en/varehandel-og-tjenesteyting/varehandel/statistikk/varehandelsindeksen

The dashboard uses original source observations and a separate hypothetical sensitivity laboratory. It does not claim causality or forecast skill.

See `methodology.md`, `executive-brief.md`, and `data.json`.
