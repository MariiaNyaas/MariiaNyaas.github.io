# Research Intelligence Brief

## Norway Retail Volume versus Turnover: The Price-Mix Illusion

**Thesis:** A positive aggregate trade reading can conceal a flat retail-volume channel.

**Verified numeric findings:**
- Aggregate–retail Q3 divergence: **0.5 percentage points**.
- Retail–wholesale Q3 divergence: **0.3 percentage points**.
- Annual–monthly aggregate difference (non-comparable horizons): **3.5 percentage points; diagnostic only**.

**Decision matrix:** If the observed divergence persists, validate exposures and stress the relevant risk appetite or valuation assumptions; if it reverses, downgrade the signal. Competing explanations include classification and timing effects.

**What would change our mind?** Subsequent official revisions or entity-level data that contradict the proposed channel.

**Practical consequence:** Monitor the next source release and independently validate any entity-specific transmission.

**Limitations:** Periods and sector scopes differ; the metrics must not be added or treated as a common time series.

Source: https://www.ssb.no/en/varehandel-og-tjenesteyting/varehandel/statistikk/varehandelsindeksen
