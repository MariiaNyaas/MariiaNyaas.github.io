# Methodology — Norway Retail Volume versus Turnover: The Price-Mix Illusion

## Source and provenance
https://www.ssb.no/en/varehandel-og-tjenesteyting/varehandel/statistikk/varehandelsindeksen

All 5 observations are directly transcribed from the cited official statistics as displayed on 5 November 2026. Periods, scope and units appear in data.json.

## Calculations
- **Aggregate–retail Q3 divergence:** 0.5 percentage points (recompute from data.json; no hidden imputation).
- **Retail–wholesale Q3 divergence:** 0.3 percentage points (recompute from data.json; no hidden imputation).
- **Annual–monthly aggregate difference (non-comparable horizons):** 3.5 percentage points; diagnostic only (recompute from data.json; no hidden imputation).

## Interpretation constraints
Periods and sector scopes differ; the metrics must not be added or treated as a common time series.

No statistical significance, causal identification, regression, or backtest is claimed.

## Interactive hypothetical scenario
`shock_percent * exposed_share_percent / 100`; the controls range 0–15% and 0–100%. Sensitivity and monotonicity checks are provided in the delivery audit.
