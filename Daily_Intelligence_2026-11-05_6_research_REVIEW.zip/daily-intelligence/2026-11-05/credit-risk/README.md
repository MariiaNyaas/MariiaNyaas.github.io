# Norwegian Mortgage Intermediation: Bank versus Mortgage-Company Exposure

**Category:** Credit Risk Intelligence
**Date:** 2026-11-05
**Status:** Review before publishing

Balance-sheet location is not the same as aggregate household credit creation.

Source: https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/banker-og-kredittforetak

The dashboard uses original source observations and a separate hypothetical sensitivity laboratory. It does not claim causality or forecast skill.

See `methodology.md`, `executive-brief.md`, and `data.json`.
