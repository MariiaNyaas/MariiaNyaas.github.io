# Research Intelligence Brief

## Norwegian Mortgage Intermediation: Bank versus Mortgage-Company Exposure

**Thesis:** Balance-sheet location is not the same as aggregate household credit creation.

**Verified numeric findings:**
- Mortgage-company loan growth Aug–Sep: **1.0 % month on month**.
- Bank loan growth Aug–Sep: **-0.3 % month on month**.
- Combined household loan growth: **0.4 % month on month**.
- Mortgage-company share, September: **59.3 % of combined stock**.

**Decision matrix:** If the observed divergence persists, validate exposures and stress the relevant risk appetite or valuation assumptions; if it reverses, downgrade the signal. Competing explanations include classification and timing effects.

**What would change our mind?** Subsequent official revisions or entity-level data that contradict the proposed channel.

**Practical consequence:** Monitor the next source release and independently validate any entity-specific transmission.

**Limitations:** The two institutional sectors must be aggregated before interpreting the direction of household lending.

Source: https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/banker-og-kredittforetak
