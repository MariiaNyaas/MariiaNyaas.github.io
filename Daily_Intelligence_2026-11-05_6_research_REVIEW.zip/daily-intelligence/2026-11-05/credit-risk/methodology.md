# Methodology — Norwegian Mortgage Intermediation: Bank versus Mortgage-Company Exposure

## Source and provenance
https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/banker-og-kredittforetak

All 4 observations are directly transcribed from the cited official statistics as displayed on 5 November 2026. Periods, scope and units appear in data.json.

## Calculations
- **Mortgage-company loan growth Aug–Sep:** 1.0 % month on month (recompute from data.json; no hidden imputation).
- **Bank loan growth Aug–Sep:** -0.3 % month on month (recompute from data.json; no hidden imputation).
- **Combined household loan growth:** 0.4 % month on month (recompute from data.json; no hidden imputation).
- **Mortgage-company share, September:** 59.3 % of combined stock (recompute from data.json; no hidden imputation).

## Interpretation constraints
The two institutional sectors must be aggregated before interpreting the direction of household lending.

No statistical significance, causal identification, regression, or backtest is claimed.

## Interactive hypothetical scenario
`shock_percent * exposed_share_percent / 100`; the controls range 0–15% and 0–100%. Sensitivity and monotonicity checks are provided in the delivery audit.
