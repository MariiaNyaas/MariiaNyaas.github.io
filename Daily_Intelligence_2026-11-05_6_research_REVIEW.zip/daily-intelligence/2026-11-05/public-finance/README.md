# Norwegian Fiscal Buffer: Surplus Compression and Revenue Sensitivity

**Category:** Public Finance Intelligence
**Date:** 2026-11-05
**Status:** Review before publishing

Revenue growth alongside faster expenditure growth can compress fiscal room even while the balance remains positive.

Source: https://www.ssb.no/en/offentlig-sektor/offentlig-forvaltning/statistikk/offentlig-forvaltnings-inntekter-og-utgifter

The dashboard uses original source observations and a separate hypothetical sensitivity laboratory. It does not claim causality or forecast skill.

See `methodology.md`, `executive-brief.md`, and `data.json`.
