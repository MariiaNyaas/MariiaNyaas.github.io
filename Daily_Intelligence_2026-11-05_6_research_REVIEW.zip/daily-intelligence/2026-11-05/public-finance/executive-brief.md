# Research Intelligence Brief

## Norwegian Fiscal Buffer: Surplus Compression and Revenue Sensitivity

**Thesis:** Revenue growth alongside faster expenditure growth can compress fiscal room even while the balance remains positive.

**Verified numeric findings:**
- Revenue growth 2024–25: **1.5 % year on year**.
- Expense growth 2024–25: **6.6 % year on year**.
- Balance decline 2024–25: **-113,210 NOK million**.
- 2025 balance / revenue: **20.3 %**.

**Decision matrix:** If the observed divergence persists, validate exposures and stress the relevant risk appetite or valuation assumptions; if it reverses, downgrade the signal. Competing explanations include classification and timing effects.

**What would change our mind?** Subsequent official revisions or entity-level data that contradict the proposed channel.

**Practical consequence:** Monitor the next source release and independently validate any entity-specific transmission.

**Limitations:** Annual general-government accounts are not the same as the central-government budget or the structural non-oil deficit.

Source: https://www.ssb.no/en/offentlig-sektor/offentlig-forvaltning/statistikk/offentlig-forvaltnings-inntekter-og-utgifter
