# Methodology — Norwegian Fiscal Buffer: Surplus Compression and Revenue Sensitivity

## Source and provenance
https://www.ssb.no/en/offentlig-sektor/offentlig-forvaltning/statistikk/offentlig-forvaltnings-inntekter-og-utgifter

All 5 observations are directly transcribed from the cited official statistics as displayed on 5 November 2026. Periods, scope and units appear in data.json.

## Calculations
- **Revenue growth 2024–25:** 1.5 % year on year (recompute from data.json; no hidden imputation).
- **Expense growth 2024–25:** 6.6 % year on year (recompute from data.json; no hidden imputation).
- **Balance decline 2024–25:** -113,210 NOK million (recompute from data.json; no hidden imputation).
- **2025 balance / revenue:** 20.3 % (recompute from data.json; no hidden imputation).

## Interpretation constraints
Annual general-government accounts are not the same as the central-government budget or the structural non-oil deficit.

No statistical significance, causal identification, regression, or backtest is claimed.

## Interactive hypothetical scenario
`shock_percent * exposed_share_percent / 100`; the controls range 0–15% and 0–100%. Sensitivity and monotonicity checks are provided in the delivery audit.
