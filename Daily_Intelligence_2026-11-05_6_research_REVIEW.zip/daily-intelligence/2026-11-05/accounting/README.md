# Sustainability Disclosure Controls: Energy Exposure and Materiality Thresholds

**Category:** Accounting & Audit Intelligence
**Date:** 2026-11-05
**Status:** Review before publishing

Rapid divergence between energy and services price dynamics raises the value of auditable exposure mapping.

Source: https://ec.europa.eu/eurostat/web/products/euro-indicators/w/2-04112026-ap

The dashboard uses original source observations and a separate hypothetical sensitivity laboratory. It does not claim causality or forecast skill.

See `methodology.md`, `executive-brief.md`, and `data.json`.
