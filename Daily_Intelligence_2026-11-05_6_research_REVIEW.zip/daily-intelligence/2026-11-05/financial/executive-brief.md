# Research Intelligence Brief

## Energy Inflation versus Core Persistence: An ECB Policy Optionality Map

**Thesis:** Headline acceleration and core stability can coexist, complicating policy interpretation.

**Verified numeric findings:**
- Headline inflation acceleration: **0.2 percentage points**.
- Energy inflation acceleration: **1.9 percentage points**.
- Energy–core rate spread: **18.3 percentage points**.

**Decision matrix:** If the observed divergence persists, validate exposures and stress the relevant risk appetite or valuation assumptions; if it reverses, downgrade the signal. Competing explanations include classification and timing effects.

**What would change our mind?** Subsequent official revisions or entity-level data that contradict the proposed channel.

**Practical consequence:** Monitor the next source release and independently validate any entity-specific transmission.

**Limitations:** Headline and component rates are not additive; component contributions require official weights and index methods.

Source: https://ec.europa.eu/eurostat/web/products/euro-indicators/w/2-04112026-ap
