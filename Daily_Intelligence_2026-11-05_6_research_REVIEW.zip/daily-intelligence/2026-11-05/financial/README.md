# Energy Inflation versus Core Persistence: An ECB Policy Optionality Map

**Category:** Financial Intelligence
**Date:** 2026-11-05
**Status:** Review before publishing

Headline acceleration and core stability can coexist, complicating policy interpretation.

Source: https://ec.europa.eu/eurostat/web/products/euro-indicators/w/2-04112026-ap

The dashboard uses original source observations and a separate hypothetical sensitivity laboratory. It does not claim causality or forecast skill.

See `methodology.md`, `executive-brief.md`, and `data.json`.
