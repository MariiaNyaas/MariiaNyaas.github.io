# Methodology — Energy Inflation versus Core Persistence: An ECB Policy Optionality Map

## Source and provenance
https://ec.europa.eu/eurostat/web/products/euro-indicators/w/2-04112026-ap

All 5 observations are directly transcribed from the cited official statistics as displayed on 5 November 2026. Periods, scope and units appear in data.json.

## Calculations
- **Headline inflation acceleration:** 0.2 percentage points (recompute from data.json; no hidden imputation).
- **Energy inflation acceleration:** 1.9 percentage points (recompute from data.json; no hidden imputation).
- **Energy–core rate spread:** 18.3 percentage points (recompute from data.json; no hidden imputation).

## Interpretation constraints
Headline and component rates are not additive; component contributions require official weights and index methods.

No statistical significance, causal identification, regression, or backtest is claimed.

## Interactive hypothetical scenario
`shock_percent * exposed_share_percent / 100`; the controls range 0–15% and 0–100%. Sensitivity and monotonicity checks are provided in the delivery audit.
