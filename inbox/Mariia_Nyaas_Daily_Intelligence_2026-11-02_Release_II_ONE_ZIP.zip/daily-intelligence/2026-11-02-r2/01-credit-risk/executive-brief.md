# Executive Brief — The Scandinavian Debt-Service Fault Line

**Decision issue.** Nordic households are exposed to different buffers: Norway’s policy rate stands at 4.50%, while the euro-area saving rate fell to 14.2% in Q2 2026. Norway and euro-area numbers are not directly comparable credit-loss statistics.

**Evidence.**
- Norway policy rate: 4.5 % — https://www.norges-bank.no/en/topics/monetary-policy/policy-rate
- EA household saving rate: 14.2 % — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-02102026-bp
- Finland saving-rate QoQ change: -1.6 pp — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-28102026-ap

**Management implication.** Stress concentration, buffer and transmission channels before extrapolating aggregate signals to individual institutions.

**Decision trigger.** Re-estimate with updated official releases and institution-specific exposures.

**Caveat.** Illustrative scenarios are not forecasts.
