# Methodology & Data Lineage

## Official data
- Norway policy rate: 4.5 % — https://www.norges-bank.no/en/topics/monetary-policy/policy-rate
- EA household saving rate: 14.2 % — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-02102026-bp
- Finland saving-rate QoQ change: -1.6 pp — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-28102026-ap

Data extracted 2026-11-02. Figures are aggregate, not individual loan-level or firm-level data.

## Scenario formula
Shock annualised incremental interest = loan principal × (rate shock / 100). Excludes amortisation, tax and repricing lags.

Inputs are user-defined, illustrative; no statistical model has been trained and no stress-calibrated probabilities are claimed.

## Limitations
Observations have different release dates and populations; comparisons are descriptive, not causal. No confidential or proprietary data.
