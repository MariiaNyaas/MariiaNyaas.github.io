# Methodology & Data Lineage

## Official data
- NFC profit share Q1: 38.4 % — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-02102026-bp
- NFC profit share Q2: 39.0 % — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-02102026-bp
- Difference: 0.6 pp — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-02102026-bp

Data extracted 2026-11-02. Figures are aggregate, not individual loan-level or firm-level data.

## Scenario formula
Untested revenue balance (million) = revenue population (million) × (1 – coverage % / 100). Coverage is a hypothetical sampling fraction, not audit assurance.

Inputs are user-defined, illustrative; no statistical model has been trained and no stress-calibrated probabilities are claimed.

## Limitations
Observations have different release dates and populations; comparisons are descriptive, not causal. No confidential or proprietary data.
