# Executive Brief — The Audit Evidence Gap Behind the Euro-Area Profit Rebound

**Decision issue.** The euro-area nonfinancial corporate profit share increased from 38.4% to 39.0% in Q2 2026. This aggregate signal motivates, but does not prove, entity-level accounting risks.

**Evidence.**
- NFC profit share Q1: 38.4 % — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-02102026-bp
- NFC profit share Q2: 39.0 % — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-02102026-bp
- Difference: 0.6 pp — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-02102026-bp

**Management implication.** Stress concentration, buffer and transmission channels before extrapolating aggregate signals to individual institutions.

**Decision trigger.** Re-estimate with updated official releases and institution-specific exposures.

**Caveat.** Illustrative scenarios are not forecasts.
