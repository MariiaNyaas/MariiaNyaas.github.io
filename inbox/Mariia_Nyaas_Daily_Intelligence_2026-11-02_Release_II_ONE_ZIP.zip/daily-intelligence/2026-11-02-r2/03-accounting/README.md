# The Audit Evidence Gap Behind the Euro-Area Profit Rebound

The euro-area nonfinancial corporate profit share increased from 38.4% to 39.0% in Q2 2026. This aggregate signal motivates, but does not prove, entity-level accounting risks.

## Verified official observations
- NFC profit share Q1: 38.4 % — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-02102026-bp
- NFC profit share Q2: 39.0 % — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-02102026-bp
- Difference: 0.6 pp — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-02102026-bp

## Model
Evidence sampling sensitivity: Illustrative untested balance under a risk-weighted sampling plan. Hypothetical assumptions; see methodology.md.
