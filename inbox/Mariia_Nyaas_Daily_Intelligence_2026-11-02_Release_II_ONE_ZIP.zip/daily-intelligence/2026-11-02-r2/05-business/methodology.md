# Methodology & Data Lineage

## Official data
- EA Q3 GDP q/q: 0.4 % — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- EA Aug industrial output m/m: -0.5 % — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/4-15102026-ap
- EA Aug construction output m/m: 1.8 % — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/4-20102026-ap

Data extracted 2026-11-02. Figures are aggregate, not individual loan-level or firm-level data.

## Scenario formula
Revenue exposed (million) = exposed annual exports (million) × contraction % / 100; assumes unit elasticity and no offset.

Inputs are user-defined, illustrative; no statistical model has been trained and no stress-calibrated probabilities are claimed.

## Limitations
Observations have different release dates and populations; comparisons are descriptive, not causal. No confidential or proprietary data.
