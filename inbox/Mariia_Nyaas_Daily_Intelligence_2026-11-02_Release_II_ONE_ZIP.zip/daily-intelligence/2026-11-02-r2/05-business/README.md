# Europe’s Two-Speed Recovery: GDP Expansion, Industrial Contraction

Aggregate GDP expansion coexists with industrial weakness, complicating export demand forecasts for Norway and Sweden. Data cover different periods and cannot be treated as a causal estimate.

## Verified official observations
- EA Q3 GDP q/q: 0.4 % — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- EA Aug industrial output m/m: -0.5 % — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/4-15102026-ap
- EA Aug construction output m/m: 1.8 % — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/4-20102026-ap

## Model
Nordic export sensitivity: Illustrative quarterly revenue shock if European demand slows. Hypothetical assumptions; see methodology.md.
