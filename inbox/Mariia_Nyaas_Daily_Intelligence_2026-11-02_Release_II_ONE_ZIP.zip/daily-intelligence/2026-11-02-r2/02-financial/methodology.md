# Methodology & Data Lineage

## Official data
- Norges Bank policy rate: 4.5 % — https://www.norges-bank.no/en/topics/monetary-policy/policy-rate
- ECB deposit facility: 2.5 % — https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html
- Rate wedge: 2.0 pp — https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html

Data extracted 2026-11-02. Figures are aggregate, not individual loan-level or firm-level data.

## Scenario formula
Annualised funding cost increment (million) = balance (million) × spread shock (bp) / 10,000.

Inputs are user-defined, illustrative; no statistical model has been trained and no stress-calibrated probabilities are claimed.

## Limitations
Observations have different release dates and populations; comparisons are descriptive, not causal. No confidential or proprietary data.
