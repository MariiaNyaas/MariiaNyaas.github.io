# The Transatlantic Rate Wedge: A Nordic Funding Stress Test

The 200bp difference between the policy reference rates is observable, not a forecast of FX returns. Scenario models reprice a hypothetical bank book, excluding hedges and behavioural optionality.

## Verified official observations
- Norges Bank policy rate: 4.5 % — https://www.norges-bank.no/en/topics/monetary-policy/policy-rate
- ECB deposit facility: 2.5 % — https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html
- Rate wedge: 2.0 pp — https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html

## Model
Funding-spread repricing: Annualised change in interest expense under an illustrative funding shock. Hypothetical assumptions; see methodology.md.
