# Executive Brief — Europe’s Fiscal Arithmetic: Debt Up as Deficits Persist

**Decision issue.** A rising debt ratio alongside persistent deficits limits fiscal optionality. A simple debt-dynamics scenario highlights nominal-growth sensitivity; it is not an official debt forecast.

**Evidence.**
- EA debt ratio Q1: 88.4 % GDP — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-bp
- EA debt ratio Q2: 88.8 % GDP — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-bp
- EA deficit ratio Q2: 3.3 % GDP — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-cp

**Management implication.** Stress concentration, buffer and transmission channels before extrapolating aggregate signals to individual institutions.

**Decision trigger.** Re-estimate with updated official releases and institution-specific exposures.

**Caveat.** Illustrative scenarios are not forecasts.
