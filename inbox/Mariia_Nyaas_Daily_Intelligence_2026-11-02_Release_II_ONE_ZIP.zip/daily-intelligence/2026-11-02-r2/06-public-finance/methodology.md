# Methodology & Data Lineage

## Official data
- EA debt ratio Q1: 88.4 % GDP — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-bp
- EA debt ratio Q2: 88.8 % GDP — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-bp
- EA deficit ratio Q2: 3.3 % GDP — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-cp

Data extracted 2026-11-02. Figures are aggregate, not individual loan-level or firm-level data.

## Scenario formula
Next debt/GDP ratio (%) = (88.8 × (1 + interest/100)/(1 + nominal growth/100)) + assumed 1% GDP primary deficit. This is an illustrative annual model and cannot be compared directly to quarterly deficit ratios.

Inputs are user-defined, illustrative; no statistical model has been trained and no stress-calibrated probabilities are claimed.

## Limitations
Observations have different release dates and populations; comparisons are descriptive, not causal. No confidential or proprietary data.
