# Europe’s Fiscal Arithmetic: Debt Up as Deficits Persist

A rising debt ratio alongside persistent deficits limits fiscal optionality. A simple debt-dynamics scenario highlights nominal-growth sensitivity; it is not an official debt forecast.

## Verified official observations
- EA debt ratio Q1: 88.4 % GDP — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-bp
- EA debt ratio Q2: 88.8 % GDP — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-bp
- EA deficit ratio Q2: 3.3 % GDP — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-cp

## Model
Debt stabilisation: Illustrative annual debt ratio after primary balance, interest and growth assumptions. Hypothetical assumptions; see methodology.md.
