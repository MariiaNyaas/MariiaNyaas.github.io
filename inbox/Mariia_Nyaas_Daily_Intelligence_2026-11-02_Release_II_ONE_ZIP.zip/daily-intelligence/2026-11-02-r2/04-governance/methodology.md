# Methodology & Data Lineage

## Official data
- Euro-area HICP Sep: 3.8 % — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap
- Norway policy rate: 4.5 % — https://www.norges-bank.no/en/topics/monetary-policy/policy-rate
- Euro-area Q3 GDP q/q: 0.4 % — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap

Data extracted 2026-11-02. Figures are aggregate, not individual loan-level or firm-level data.

## Scenario formula
Value affected (million) = daily transactions (million) × outage hours / 24; not equivalent to economic loss.

Inputs are user-defined, illustrative; no statistical model has been trained and no stress-calibrated probabilities are claimed.

## Limitations
Observations have different release dates and populations; comparisons are descriptive, not causal. No confidential or proprietary data.
