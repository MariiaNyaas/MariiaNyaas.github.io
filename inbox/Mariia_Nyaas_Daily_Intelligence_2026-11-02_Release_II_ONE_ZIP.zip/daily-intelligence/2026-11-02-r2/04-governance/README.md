# The DORA Control Gap in a High-Cyber-Risk Nordic Banking System

A resilient balance sheet is not a substitute for operational resilience. The quantitative exercise is a business-impact scenario, not an empirical frequency model.

## Verified official observations
- Euro-area HICP Sep: 3.8 % — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap
- Norway policy rate: 4.5 % — https://www.norges-bank.no/en/topics/monetary-policy/policy-rate
- Euro-area Q3 GDP q/q: 0.4 % — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap

## Model
Cyber outage cost: Hypothetical transaction-loss exposure during a major provider outage. Hypothetical assumptions; see methodology.md.
