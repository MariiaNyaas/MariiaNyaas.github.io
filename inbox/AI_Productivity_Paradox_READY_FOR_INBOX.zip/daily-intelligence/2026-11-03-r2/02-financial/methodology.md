# Methodology — The AI Productivity Paradox

**Edition:** 2026-11-03  
**Classification:** Independent exploratory research; descriptive analysis and explicitly hypothetical scenario modelling.

## Research question

Can investment and AI adoption indicators precede a measurable productivity response, and how sensitive is that apparent relationship to the chosen indicator, time window, transformation and lag?

This is motivated by public discussion of the AI investment cycle and concentration, but it is **not** a question attributed verbatim to Nicolai Tangen or a study commissioned by NBIM.

## Primary dataset

Federal Reserve Board, *The AI Buildout*, FEDS Notes, 17 July 2026, **figure-data XLSX**:
https://www.federalreserve.gov/econres/notes/feds-notes/feds-ai-buildout-figure-data.xlsx

The supplied workbook contains `Data_Sources` and `Figure_1` through `Figure_11`. The packaged `data.json` retains 11 figure worksheets with 627 observations/records across their native periods. `variables.json` documents 26 selectable indicators. The original XLSX should be retained for full provenance and independent reproducibility. Figure_1 and Figure_2 are event-level observations, preserved in the JSON but excluded from quarterly comparisons.

**Important:** The figure data do not contain stock prices, valuations, consensus earnings, risk premia or a direct measure of aggregate AI-attributable total-factor productivity. The dashboard therefore cannot establish whether the market has priced AI correctly.

## Extraction

- Original workbook rows 1–3 contain figure titles, units and spacing; row 4 contains column headings.
- Valid observation rows start at row 5. Source footers and other non-date rows are excluded.
- Dates are retained as ISO dates, YYYY-MM months or YYYY:Qn quarters.
- Numeric-looking cells, including text-formatted numerical values in Figure_7, are parsed as numbers.
- Missing values remain null. No forward fill, interpolation or estimation is applied.
- Figure_4 CAPEX is **nominal USD billions per quarter**, not pure AI spending.
- Figure_5 mixes monthly construction and quarterly equipment values; quarterly aggregation follows the rules below.
- Figure_9 provides quarterly productivity growth as a **four-quarter moving average**; this is not a productivity level.

## Time alignment and correlation

1. Each observation is assigned to its calendar quarter.
2. If a series contains multiple observations in a quarter, their arithmetic mean is used. This is a visual-alignment convenience; a monthly level or index averaged across a quarter is not equivalent to a quarterly flow or quarterly total.
3. Select two series, A and B. With lag L, pair A(t) with B(t+L).
4. Restrict to the selected calendar window and to available observations in both series.
5. Available transformations: native values, rebased indices to 100 at the first common non-zero pair, first differences, and quarter-on-quarter percentage changes.
6. First differences and percentage changes are only calculated for *consecutive* available quarters. Percentage changes are omitted if the previous value is zero.
7. Pearson correlation is displayed only for at least eight matched quarters with non-zero variance.

The correlation is descriptive. Serial correlation, smoothing in the source data, common trends, omitted variables, simultaneity and short samples can invalidate causal interpretations. Rebased level correlations are particularly vulnerable to spurious trend correlation. Comparing transformed series is a sensitivity check, not causal identification.

## Adoption and productivity panels

The adoption panel plots small (1–4 employees) and large (250+ employees) firms from Figure_8. Observations are not extrapolated beyond available survey dates.

The productivity panel compares high and low AI-exposure sector groups from Figure_9, which are four-quarter moving-average quarterly growth rates. Their difference does **not** identify an AI treatment effect; sector composition, business cycle, capital intensity and pre-existing trends are potential confounders.

## Hypothetical sensitivity laboratory

Ten analyst-defined sliders:

1. Business adoption rate (%)
2. Share of tasks influenced by AI (%)
3. Productivity gain on influenced tasks (%)
4. Benefit realisation factor (%)
5. Deployment delay (quarters)
6. Evaluation horizon (quarters)
7. Annual benefit erosion (%)
8. Initial investment burden (analyst-defined points)
9. Annual operating burden (analyst-defined points)
10. Annual discount rate (%)

The annual uplift is `adoption × task reach × task gain × realisation`, with all four inputs converted from percentages to fractions. This is a hypothetical arithmetic mapping, **not** an empirical estimate or calibration to the Federal Reserve data.

For quarters after the deployment delay, an assumed annual uplift is discounted by an annual erosion factor. Annual uplift and operating burden are divided by four to form a quarterly benefit-index flow. Each quarterly net flow is discounted at `(1 + annual_discount_rate)^(quarter/4)`. The initial investment burden is deducted once. The break-even adoption threshold uses linear scaling of gross benefits with adoption, holding all other assumptions fixed. When no benefit can be generated, break-even is undefined.

The scenario output is an **analyst-defined index**. It is not percentage-point GDP growth, firm earnings, net present value in currency, equity valuation or a probabilistic forecast. Its units should not be interpreted as an observed economic quantity.

## Limitations and governance

- AI-related and non-AI technology investment cannot be separated precisely from the CAPEX aggregates.
- The source figures cover different periods and frequencies; some series overlap for very few quarters.
- Figure_7 GDP growth contributions are in percentage points and must not be treated as investment shares.
- The dashboard does not identify a causal effect or validate either research hypothesis.
- No inference about Norges Bank Investment Management's holdings or investment decisions is made.
- Research findings should be interpreted with the published source methodology and figure footnotes.
- No confidential employer information is included.

## Reproduction

Open `index.html` in a modern browser. The source observations and variable dictionary are embedded in the HTML, so no network or external JavaScript library is required. `data.json` and `variables.json` are also provided separately for machine-readable reuse. Use the built-in export controls to download the currently aligned CSV and the complete extracted data.

The original XLSX is the authoritative source; if the source is revised, repeat extraction and document the revision date.
