# Executive brief — The AI Productivity Paradox

**03 November 2026 · Financial Intelligence**

## The question
Does investment in AI infrastructure precede a measurable rise in productivity, or do headline investment signals overstate the pace of economic transformation?

## What we can measure
The Federal Reserve figure-data workbook provides investment, infrastructure, adoption, productivity and labour-market indicators. The interactive dashboard offers 26 selectable historical indicators, lagged comparison and 10 analyst-defined scenario assumptions.

## What we cannot claim
Correlations do not identify causality. Hyperscaler CAPEX is not entirely AI investment. The source workbook does not provide equity valuations, earnings expectations or risk premia; no inference is made about whether equities are mispriced.

## Research approach
Use the historical comparison to explore lag sensitivity, compare high- and low-AI-exposure productivity, and stress hypothetical diffusion assumptions. Report sample size, transformations and limitations alongside each result.

## Decision implication
Interpret apparent AI investment-productivity gaps as questions for further empirical testing, not as forecasts or investment signals.
