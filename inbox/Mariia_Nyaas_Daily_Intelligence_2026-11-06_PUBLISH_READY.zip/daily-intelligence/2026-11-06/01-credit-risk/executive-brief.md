# The Employment Buffer Under a Higher Rate

**Research date:** 2026-11-06 · **Domain:** Credit Risk Intelligence

## Executive thesis
Stable employment does not rule out borrower cash-flow stress: debt-service repricing can precede job losses. This is a falsifiable mechanism hypothesis, not a measured causal relationship.

## Verified observations and reproducible calculations
- **Norway policy rate: 4.50%** — Norges Bank, 5 Nov 2026
- **Unemployment: 4.6%** — SSB trend, Sep 2026
- **Employment rate: 69.8%** — SSB trend, Sep 2026
- **Employed persons: 2,928,000** — SSB trend, Sep 2026

## Mechanism and second-order effects
Potential transmission channels: policy-rate pass-through, floating-rate debt stock, real disposable income, employment resilience. Interaction and lag structure are unestimated. A headline signal can differ from firm-level outcomes due to mix, contracts, financing and geography.

## Decision matrix
| Conditional pattern | Competing explanation | Decision | Additional evidence |
|---|---|---|---|
| Signal persists | Composition or revisions | Run controlled pilot / stress | Segment-level actuals |
| Signal reverses | Seasonal noise | Defer irreversible capital | Next two releases |
| Macro and micro diverge | Company-specific hedges | Reconcile exposures | Contract-level reconciliation |

## What would change our mind?
Household arrears remain flat across repricing cohorts despite sustained high rates.

## Leading indicator
Arrears and payment deferrals by loan-vintage, before unemployment rises.

## Sources
- [Norges Bank rate decision, 5 Nov 2026](https://www.norges-bank.no/en/news-events/news/Speeches/2026/2026-11-05-pc/)
- [SSB Labour Force Survey, 5 Nov 2026](https://www.ssb.no/en/arbeid-og-lonn/sysselsetting/statistikk/arbeidskraftundersokelsen)

## Limitations
No causal claim, statistical fit, predictive accuracy, or investment advice. Scenario values are hypothetical.


## Research integrity note

The dashboard includes a clearly hypothetical two-factor sensitivity grid. Its inputs must not be interpreted as estimated probabilities, observed outcomes or forecasts. Source observations have incompatible units and are therefore not compared using a common magnitude axis.
