# Methodology — The Employment Buffer Under a Higher Rate

Observation date and units are stated beside every data point in `data.json`. Inputs are transcribed from the primary sources below. No missing time series were filled.

- **Norway policy rate: 4.50%** — Norges Bank, 5 Nov 2026
- **Unemployment: 4.6%** — SSB trend, Sep 2026
- **Employment rate: 69.8%** — SSB trend, Sep 2026
- **Employed persons: 2,928,000** — SSB trend, Sep 2026

## Scenario model
`loan * rateShock / 100`. NOK 3,000,000 illustrative principal; excludes tax and amortisation. The slider does not update the observed figures. Bounds: 0–3, step 0.25. All scenario outputs are hypothetical.

## Transmission hypothesis
Stable employment does not rule out borrower cash-flow stress: debt-service repricing can precede job losses. Drivers: policy-rate pass-through, floating-rate debt stock, real disposable income, employment resilience. No estimated lag, correlation, backtest or counterfactual attribution.

## Falsification
Household arrears remain flat across repricing cohorts despite sustained high rates.

## Sources
- [Norges Bank rate decision, 5 Nov 2026](https://www.norges-bank.no/en/news-events/news/Speeches/2026/2026-11-05-pc/)
- [SSB Labour Force Survey, 5 Nov 2026](https://www.ssb.no/en/arbeid-og-lonn/sysselsetting/statistikk/arbeidskraftundersokelsen)

## Methodological caveats
Small manually verified release extracts; do not extrapolate to populations or make firm-level investment decisions without microdata.


## Dimensional audit and independent scenario drivers

The original magnitude bars were removed because different units cannot be compared on a common axis. The added two-factor grid varies independent **hypothetical** drivers, without implying that the input values were sampled or calibrated.

Assumes interest-only incremental annual expense before tax and amortisation. The principal and pass-through are assumptions, not sampled borrower data.

The grid is a deterministic sensitivity illustration, not an econometric estimate. No causal, lead–lag, predictive, sectoral or cross-sectional claims can be validated from the current release snapshots. Replication requires the cited source releases and the stated arithmetic assumptions.
