# The Employment Buffer Under a Higher Rate

Daily Intelligence · 2026-11-06 · Credit Risk Intelligence

Interactive dashboard: [Preview after approval](https://mariianyaas.github.io/daily-intelligence/2026-11-06/01-credit-risk/) — **NOT YET PUBLISHED**.

Files: `index.html`, `data.json`, `README.md`, `methodology.md`, `executive-brief.md`, `project.json`.

Thesis: Stable employment does not rule out borrower cash-flow stress: debt-service repricing can precede job losses.

Sources:
- [Norges Bank rate decision, 5 Nov 2026](https://www.norges-bank.no/en/news-events/news/Speeches/2026/2026-11-05-pc/)
- [SSB Labour Force Survey, 5 Nov 2026](https://www.ssb.no/en/arbeid-og-lonn/sysselsetting/statistikk/arbeidskraftundersokelsen)

No publication is authorised by creation of this bundle.


### Review status
This is a research-review candidate, **not institutionally validated or cleared for publication**. Empirical cross-source identification, lead-lag estimation and browser end-to-end testing remain outstanding.
