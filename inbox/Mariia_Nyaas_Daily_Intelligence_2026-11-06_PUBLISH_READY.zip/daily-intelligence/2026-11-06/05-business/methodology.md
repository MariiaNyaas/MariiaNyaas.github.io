# Methodology — Foreign Tourism: Growth and Concentration

Observation date and units are stated beside every data point in `data.json`. Inputs are transcribed from the primary sources below. No missing time series were filled.

- **Hotel guest nights: 2,579,128** — September 2026; SSB
- **Foreign hotel nights: 841,630** — September 2026; SSB
- **Foreign share: 32.63%** — 841,630/2,579,128; Sep 2026
- **Foreign hotel growth: +7.4% YoY** — Sep 2025–Sep 2026
- **Domestic hotel growth: +0.6% YoY** — Sep 2025–Sep 2026

## Scenario model
`incremental foreign nights × assumed nightly revenue`. Incremental nights approximated from 841,630 / 1.074; illustrative price, not observed ADR. The slider does not update the observed figures. Bounds: 600–2400, step 100. All scenario outputs are hypothetical.

## Transmission hypothesis
Foreign guest-night growth is much faster than domestic growth, creating upside but also source-market and distribution risk. Drivers: foreign origin mix, hotel capacity, room-rate yield, air connectivity. No estimated lag, correlation, backtest or counterfactual attribution.

## Falsification
Foreign-night acceleration reverses without improvement in hotel margins.

## Sources
- [SSB accommodation September 2026, 4 Nov 2026](https://www.ssb.no/en/transport-og-reiseliv/reiseliv/statistikk/overnattingar)
- [SSB September hotel release, 4 Nov 2026](https://www.ssb.no/transport-og-reiseliv/reiseliv/statistikk/overnattingar/artikler/fleire-utanlandske-overnattingar-gav-septemberrekord-ved-norske-hotell)

## Methodological caveats
Small manually verified release extracts; do not extrapolate to populations or make firm-level investment decisions without microdata.


## Dimensional audit and independent scenario drivers

The original magnitude bars were removed because different units cannot be compared on a common axis. The added two-factor grid varies independent **hypothetical** drivers, without implying that the input values were sampled or calibrated.

Illustrative incremental foreign overnight stays × assumed spend per night; neither realised room revenue nor net value added. The underlying base is reconstructed from a reported growth rate.

The grid is a deterministic sensitivity illustration, not an econometric estimate. No causal, lead–lag, predictive, sectoral or cross-sectional claims can be validated from the current release snapshots. Replication requires the cited source releases and the stated arithmetic assumptions.
