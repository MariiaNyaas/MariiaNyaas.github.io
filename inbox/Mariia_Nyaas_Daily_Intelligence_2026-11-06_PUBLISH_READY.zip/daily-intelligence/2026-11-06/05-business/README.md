# Foreign Tourism: Growth and Concentration

Daily Intelligence · 2026-11-06 · Business & Economic Intelligence

Interactive dashboard: [Preview after approval](https://mariianyaas.github.io/daily-intelligence/2026-11-06/05-business/) — **NOT YET PUBLISHED**.

Files: `index.html`, `data.json`, `README.md`, `methodology.md`, `executive-brief.md`, `project.json`.

Thesis: Foreign guest-night growth is much faster than domestic growth, creating upside but also source-market and distribution risk.

Sources:
- [SSB accommodation September 2026, 4 Nov 2026](https://www.ssb.no/en/transport-og-reiseliv/reiseliv/statistikk/overnattingar)
- [SSB September hotel release, 4 Nov 2026](https://www.ssb.no/transport-og-reiseliv/reiseliv/statistikk/overnattingar/artikler/fleire-utanlandske-overnattingar-gav-septemberrekord-ved-norske-hotell)

No publication is authorised by creation of this bundle.


### Review status
This is a research-review candidate, **not institutionally validated or cleared for publication**. Empirical cross-source identification, lead-lag estimation and browser end-to-end testing remain outstanding.
