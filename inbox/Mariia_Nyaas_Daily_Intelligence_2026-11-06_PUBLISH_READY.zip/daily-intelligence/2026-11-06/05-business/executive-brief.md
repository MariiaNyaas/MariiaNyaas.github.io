# Foreign Tourism: Growth and Concentration

**Research date:** 2026-11-06 · **Domain:** Business & Economic Intelligence

## Executive thesis
Foreign guest-night growth is much faster than domestic growth, creating upside but also source-market and distribution risk. This is a falsifiable mechanism hypothesis, not a measured causal relationship.

## Verified observations and reproducible calculations
- **Hotel guest nights: 2,579,128** — September 2026; SSB
- **Foreign hotel nights: 841,630** — September 2026; SSB
- **Foreign share: 32.63%** — 841,630/2,579,128; Sep 2026
- **Foreign hotel growth: +7.4% YoY** — Sep 2025–Sep 2026
- **Domestic hotel growth: +0.6% YoY** — Sep 2025–Sep 2026

## Mechanism and second-order effects
Potential transmission channels: foreign origin mix, hotel capacity, room-rate yield, air connectivity. Interaction and lag structure are unestimated. A headline signal can differ from firm-level outcomes due to mix, contracts, financing and geography.

## Decision matrix
| Conditional pattern | Competing explanation | Decision | Additional evidence |
|---|---|---|---|
| Signal persists | Composition or revisions | Run controlled pilot / stress | Segment-level actuals |
| Signal reverses | Seasonal noise | Defer irreversible capital | Next two releases |
| Macro and micro diverge | Company-specific hedges | Reconcile exposures | Contract-level reconciliation |

## What would change our mind?
Foreign-night acceleration reverses without improvement in hotel margins.

## Leading indicator
Source-market bookings and RevPAR by origin, not just total overnight stays.

## Sources
- [SSB accommodation September 2026, 4 Nov 2026](https://www.ssb.no/en/transport-og-reiseliv/reiseliv/statistikk/overnattingar)
- [SSB September hotel release, 4 Nov 2026](https://www.ssb.no/transport-og-reiseliv/reiseliv/statistikk/overnattingar/artikler/fleire-utanlandske-overnattingar-gav-septemberrekord-ved-norske-hotell)

## Limitations
No causal claim, statistical fit, predictive accuracy, or investment advice. Scenario values are hypothetical.


## Research integrity note

The dashboard includes a clearly hypothetical two-factor sensitivity grid. Its inputs must not be interpreted as estimated probabilities, observed outcomes or forecasts. Source observations have incompatible units and are therefore not compared using a common magnitude axis.
