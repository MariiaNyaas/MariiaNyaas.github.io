# The Energy–Core Divergence: A Governance Stress Test

Independent decision intelligence, dated 6 November 2026.

Files: `index.html` interactive dashboard; `data.json` observed extracts, sources and limitations; `executive-brief.md`; `methodology.md`; `project.json`; `README.md`.

**Status:** Review, not published. All scenario inputs are hypothetical. Sources are linked inside the dashboard. Do not infer causation, forecasting accuracy or investment recommendations.
