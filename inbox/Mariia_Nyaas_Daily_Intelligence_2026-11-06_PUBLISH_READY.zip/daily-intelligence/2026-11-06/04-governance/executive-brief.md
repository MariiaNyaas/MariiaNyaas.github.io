# The Energy–Core Divergence: A Governance Stress Test

**6 November 2026 · Risk & Governance Intelligence**

## Executive thesis
A rising headline rate alongside stable core inflation is a governance problem of exposure mapping—not evidence that every borrower faces the same inflation shock.

## Research Intelligence Brief — verified observations and arithmetic
- **Headline acceleration: +0.2 pp** — 4.0 − 3.8, Oct vs Sep 2026, Eurostat
- **Energy annual-rate acceleration: +1.9 pp** — 20.8 − 18.9, Oct vs Sep 2026, Eurostat
- **Core inflation change: 0.0 pp** — 2.5 − 2.5, Oct vs Sep 2026, Eurostat
- **Headline–core gap, October: 1.5 pp** — 4.0 − 2.5, October 2026, Eurostat
- **Norges Bank policy rate: 4.50%** — 5 Nov 2026, Norges Bank

## Mechanism and leading indicators
Energy HICP annual-rate acceleration; sticky services; flat core; Norwegian rate hold; hedging and currency basis.

## Investor / decision matrix
| Conditional pattern | Competing explanation | Governance response | Evidence needed |
|---|---|---|---|
| Shock persists in operating data | Temporary price / activity mix | Escalate sensitivity and concentration review | Firm and sector invoices, hedge maturities |
| Macro shock reverses | Statistical noise or revision | Reassess stress assumptions | Next official release, same vintage |
| Macro and micro diverge | Contract protection / sector composition | Segment risk limits rather than blanket action | Exposure-weighted reconciliations |

## What would change our mind?
Subsequent releases revise the energy impulse away, and borrower-level energy bills and margins show no deterioration.

## Limitations
- October HICP figures are preliminary and subject to revision.
- Euro-area annual inflation is not Norwegian inflation; policy rates and inflation rates are different constructs.
- Six monthly observations cannot establish causality or predictive lead–lag.
- A simple energy exposure stress is a user-input cash-flow illustration, not a calibrated macro model.

## Primary sources
- [Eurostat October 2026 flash HICP, released 4 November 2026](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-04112026-ap)
- [Norges Bank 5 November 2026 policy decision listing](https://www.norges-bank.no/en/news-events/news/)
