# Methodology — The Energy–Core Divergence: A Governance Stress Test

## Research question
Does a widening energy–core inflation gap warrant differentiated cross-border risk controls?

The six-month euro-area release extract is **descriptive**, not an econometric panel. Annual rates for each component are plotted separately; differences between annual rates are expressed in percentage points, not monthly inflation. Core means all items excluding energy, food, alcohol and tobacco. Euro-area HICP does not measure Norwegian CPI.

## Reproducible derived measures
Headline delta = 4.0−3.8 = +0.2 pp; energy delta = 20.8−18.9 = +1.9 pp; core delta = 2.5−2.5 = 0 pp; October headline minus core = 1.5 pp. These differences are diagnostic, not contributions to headline inflation. Component contributions require index weights and chain-linked aggregation.

## Scenario model (not calibrated)
Incremental annual unhedged energy cost = annual energy expenditure (NOK million) × assumed incremental price shock (%) / 100 × (1−hedged share/100). Cash-flow coverage after stress = starting annual liquidity buffer minus incremental cost. This is a contract exposure stress, not an inflation pass-through estimate.

## Falsification and governance
If later HICP revisions reverse energy acceleration, and firm-level contracted energy costs remain stable, the exposure-escalation hypothesis weakens. Examine invoice price, hedge maturity, borrower energy intensity, NOK/EUR and refinancing dates before changing limits.

## Sources and limitations
- [Eurostat October 2026 flash HICP, released 4 November 2026](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-04112026-ap)
- [Norges Bank 5 November 2026 policy decision listing](https://www.norges-bank.no/en/news-events/news/)
- October HICP figures are preliminary and subject to revision.
- Euro-area annual inflation is not Norwegian inflation; policy rates and inflation rates are different constructs.
- Six monthly observations cannot establish causality or predictive lead–lag.
- A simple energy exposure stress is a user-input cash-flow illustration, not a calibrated macro model.