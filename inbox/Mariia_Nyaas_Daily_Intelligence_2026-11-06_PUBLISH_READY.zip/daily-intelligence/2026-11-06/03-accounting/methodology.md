# Methodology — Services Turnover: A Revenue Cut-off Warning

Observation date and units are stated beside every data point in `data.json`. Inputs are transcribed from the primary sources below. No missing time series were filled.

- **September monthly change: −1.2%** — SSB seasonally adjusted
- **Three-month change: +1.7%** — SSB seasonally adjusted
- **September annual change: +5.3%** — SSB calendar adjusted
- **Monthly versus annual spread: 6.5 percentage points** — 5.3−(−1.2); not directly comparable adjustment basis

## Scenario model
`100m × adjustment / 100`. Pure audit sensitivity, not an estimate of misstatement. The slider does not update the observed figures. Bounds: 0–5, step 0.25. All scenario outputs are hypothetical.

## Transmission hypothesis
A positive annual turnover comparison does not validate period-end revenue recognition when sequential activity is weakening. Drivers: seasonal adjustment, contract milestones, billing cut-off, segment mix. No estimated lag, correlation, backtest or counterfactual attribution.

## Falsification
Contract-level reconciliations show matched delivery and billing despite the monthly decline.

## Sources
- [SSB turnover index for services, 5 Nov 2026](https://www.ssb.no/en/varehandel-og-tjenesteyting/tjenesteyting/statistikk/omsetningsindeks-for-tjenester)

## Methodological caveats
Small manually verified release extracts; do not extrapolate to populations or make firm-level investment decisions without microdata.


## Dimensional audit and independent scenario drivers

The original magnitude bars were removed because different units cannot be compared on a common axis. The added two-factor grid varies independent **hypothetical** drivers, without implying that the input values were sampled or calibrated.

Purely hypothetical materiality sensitivity; not an estimate of misstatement, fraud or revenue growth. Revenue bases are illustrative.

The grid is a deterministic sensitivity illustration, not an econometric estimate. No causal, lead–lag, predictive, sectoral or cross-sectional claims can be validated from the current release snapshots. Replication requires the cited source releases and the stated arithmetic assumptions.
