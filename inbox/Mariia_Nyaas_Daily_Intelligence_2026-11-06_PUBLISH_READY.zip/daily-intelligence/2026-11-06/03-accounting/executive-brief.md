# Services Turnover: A Revenue Cut-off Warning

**Research date:** 2026-11-06 · **Domain:** Accounting & Audit Intelligence

## Executive thesis
A positive annual turnover comparison does not validate period-end revenue recognition when sequential activity is weakening. This is a falsifiable mechanism hypothesis, not a measured causal relationship.

## Verified observations and reproducible calculations
- **September monthly change: −1.2%** — SSB seasonally adjusted
- **Three-month change: +1.7%** — SSB seasonally adjusted
- **September annual change: +5.3%** — SSB calendar adjusted
- **Monthly versus annual spread: 6.5 percentage points** — 5.3−(−1.2); not directly comparable adjustment basis

## Mechanism and second-order effects
Potential transmission channels: seasonal adjustment, contract milestones, billing cut-off, segment mix. Interaction and lag structure are unestimated. A headline signal can differ from firm-level outcomes due to mix, contracts, financing and geography.

## Decision matrix
| Conditional pattern | Competing explanation | Decision | Additional evidence |
|---|---|---|---|
| Signal persists | Composition or revisions | Run controlled pilot / stress | Segment-level actuals |
| Signal reverses | Seasonal noise | Defer irreversible capital | Next two releases |
| Macro and micro diverge | Company-specific hedges | Reconcile exposures | Contract-level reconciliation |

## What would change our mind?
Contract-level reconciliations show matched delivery and billing despite the monthly decline.

## Leading indicator
Monthly unbilled revenue, credit notes and contract-asset ageing.

## Sources
- [SSB turnover index for services, 5 Nov 2026](https://www.ssb.no/en/varehandel-og-tjenesteyting/tjenesteyting/statistikk/omsetningsindeks-for-tjenester)

## Limitations
No causal claim, statistical fit, predictive accuracy, or investment advice. Scenario values are hypothetical.


## Research integrity note

The dashboard includes a clearly hypothetical two-factor sensitivity grid. Its inputs must not be interpreted as estimated probabilities, observed outcomes or forecasts. Source observations have incompatible units and are therefore not compared using a common magnitude axis.
