# Methodology — Norway’s Climate Delivery Gap: Sector Concentration and the 2030 Arithmetic

## Research question
Where does the national emissions trajectory hide sector-specific execution risk?

SSB's final 2025 territorial emissions release of 4 November 2026 is the sole statistical vintage for the displayed 1990–2025 extract. This vintage revises road-traffic estimates back to 1990. Years shown are **selected observed years**, not an interpolated annual series. Sector values are rounded and must not be summed to reconstruct the total exactly.

## Reproducible derived measures
2025 decline in displayed rounded levels = 44.8−44.0 = 0.8 MtCO₂e. Illustrative 2030 55%-below-1990 reference = 51.2×(1−0.55)=23.04 MtCO₂e. Distance = 44.0−23.04=20.96 MtCO₂e. The comparator is **not** an official domestic compliance gap: LULUCF, international flexibility and EU cooperation affect target accounting.

## Scenario model (not a forecast)
Illustrative 2030 territorial emissions = 44.0 − assumed annual domestic abatement (MtCO₂e) × 5 + assumed annual rebound (MtCO₂e) × 5. Constant increments over 2026–2030 are explicitly hypothetical. Required annual reduction to reach illustrative reference = 20.96/5 = 4.192 MtCO₂e/year; compare with rounded 2024–2025 decline of 0.8 MtCO₂e. This does not model feasibility or costs.

## Sector signals and counter-explanations
Manufacturing emissions rose 1.0% year-on-year while road transport fell 8.1%; temporary plant activity and methodological revisions can affect comparisons. Monitoring should focus on verified sector deliveries, capex commissioning and measurement vintages, not a single national headline.

## Sources and limitations
- [SSB final 2025 emissions and revised series, 4 November 2026](https://www.ssb.no/en/natur-og-miljo/forurensning-og-klima/statistikk/utslipp-til-luft)
- [SSB analysis and 2030 target explanation, 4 November 2026](https://www.ssb.no/natur-og-miljo/forurensning-og-klima/statistikk/utslipp-til-luft/artikler/norge-har-kuttet-14-prosent-i-klimagasser-siden-1990)
- SSB category totals are rounded and may not add to 44.0 MtCO₂e.
- The 1990 baseline is revised; do not splice unrevised historical vintages.
- Territorial emissions exclude LULUCF and international transport; target compliance also involves EU cooperation and possible international flexibility.
- The 55% target benchmark is an arithmetic comparator, not a claim that domestic territorial emissions alone must meet that number.
- No fiscal spending or marginal abatement cost series is estimated.