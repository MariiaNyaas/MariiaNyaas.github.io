# Norway’s Climate Delivery Gap: Sector Concentration and the 2030 Arithmetic

**6 November 2026 · Public Finance Intelligence**

## Executive thesis
The national emissions decline masks divergent sector paths: road transport is falling, while industry rose in 2025. The resulting delivery risk is sector-specific, not a single national trend.

## Research Intelligence Brief — verified observations and arithmetic
- **2025 territorial emissions: 44.0 MtCO₂e** — SSB final 2025
- **2025 vs 1990: −14.1%** — SSB revised series
- **2024 to 2025 decline: 0.8 MtCO₂e** — 44.8−44.0; rounded SSB values
- **2030 55%-below-1990 benchmark: 23.04 MtCO₂e** — 51.2 × 0.45; arithmetic territorial comparator only
- **Gap to illustrative benchmark: 20.96 MtCO₂e** — 44.0−23.04; not a compliance shortfall estimate

## Mechanism and leading indicators
Road traffic electrification; manufacturing activity; oil-and-gas operations; investment timing; accounting revisions.

## Investor / decision matrix
| Conditional pattern | Competing explanation | Governance response | Evidence needed |
|---|---|---|---|
| Shock persists in operating data | Temporary price / activity mix | Escalate sensitivity and concentration review | Firm and sector invoices, hedge maturities |
| Macro shock reverses | Statistical noise or revision | Reassess stress assumptions | Next official release, same vintage |
| Macro and micro diverge | Contract protection / sector composition | Segment risk limits rather than blanket action | Exposure-weighted reconciliations |

## What would change our mind?
Verified sector-level abatement accelerates across industry and transport, with funded and commissioned measures closing the illustrative trajectory gap.

## Limitations
- SSB category totals are rounded and may not add to 44.0 MtCO₂e.
- The 1990 baseline is revised; do not splice unrevised historical vintages.
- Territorial emissions exclude LULUCF and international transport; target compliance also involves EU cooperation and possible international flexibility.
- The 55% target benchmark is an arithmetic comparator, not a claim that domestic territorial emissions alone must meet that number.
- No fiscal spending or marginal abatement cost series is estimated.

## Primary sources
- [SSB final 2025 emissions and revised series, 4 November 2026](https://www.ssb.no/en/natur-og-miljo/forurensning-og-klima/statistikk/utslipp-til-luft)
- [SSB analysis and 2030 target explanation, 4 November 2026](https://www.ssb.no/natur-og-miljo/forurensning-og-klima/statistikk/utslipp-til-luft/artikler/norge-har-kuttet-14-prosent-i-klimagasser-siden-1990)
