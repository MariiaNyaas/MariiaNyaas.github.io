# Salmon Export Value: The Price–Volume Collision

Daily Intelligence · 2026-11-06 · Financial Intelligence

Interactive dashboard: [Preview after approval](https://mariianyaas.github.io/daily-intelligence/2026-11-06/02-financial/) — **NOT YET PUBLISHED**.

Files: `index.html`, `data.json`, `README.md`, `methodology.md`, `executive-brief.md`, `project.json`.

Thesis: The price decline offsets part of fresh salmon volume expansion; export value is a product, not a volume story.

Sources:
- [SSB weekly salmon exports, 4 Nov 2026](https://www.ssb.no/en/utenriksokonomi/utenrikshandel/statistikk/eksport-av-laks)

No publication is authorised by creation of this bundle.


### Review status
This is a research-review candidate, **not institutionally validated or cleared for publication**. Empirical cross-source identification, lead-lag estimation and browser end-to-end testing remain outstanding.
