# Salmon Export Value: The Price–Volume Collision

**Research date:** 2026-11-06 · **Domain:** Financial Intelligence

## Executive thesis
The price decline offsets part of fresh salmon volume expansion; export value is a product, not a volume story. This is a falsifiable mechanism hypothesis, not a measured causal relationship.

## Verified observations and reproducible calculations
- **Fresh price: NOK 74.98/kg** — Week 44 2026; SSB
- **Fresh export volume: 28,444 tonnes** — Week 44 2026; SSB
- **Fresh volume growth: +14.3% YoY** — Week 44 2026; SSB
- **Implied export value growth: +6.41% YoY** — (1−0.069)×(1+0.143)−1; price×volume proxy

## Mechanism and second-order effects
Potential transmission channels: export price, shipped tonnes, feed and energy costs, currency conversion. Interaction and lag structure are unestimated. A headline signal can differ from firm-level outcomes due to mix, contracts, financing and geography.

## Decision matrix
| Conditional pattern | Competing explanation | Decision | Additional evidence |
|---|---|---|---|
| Signal persists | Composition or revisions | Run controlled pilot / stress | Segment-level actuals |
| Signal reverses | Seasonal noise | Defer irreversible capital | Next two releases |
| Macro and micro diverge | Company-specific hedges | Reconcile exposures | Contract-level reconciliation |

## What would change our mind?
Net realised margins rise despite weaker export prices through cost or FX improvements.

## Leading indicator
Weekly price × tonnes alongside farm-level operating cost per kg.

## Sources
- [SSB weekly salmon exports, 4 Nov 2026](https://www.ssb.no/en/utenriksokonomi/utenrikshandel/statistikk/eksport-av-laks)

## Limitations
No causal claim, statistical fit, predictive accuracy, or investment advice. Scenario values are hypothetical.


## Research integrity note

The dashboard includes a clearly hypothetical two-factor sensitivity grid. Its inputs must not be interpreted as estimated probabilities, observed outcomes or forecasts. Source observations have incompatible units and are therefore not compared using a common magnitude axis.
