# Methodology — Salmon Export Value: The Price–Volume Collision

Observation date and units are stated beside every data point in `data.json`. Inputs are transcribed from the primary sources below. No missing time series were filled.

- **Fresh price: NOK 74.98/kg** — Week 44 2026; SSB
- **Fresh export volume: 28,444 tonnes** — Week 44 2026; SSB
- **Fresh volume growth: +14.3% YoY** — Week 44 2026; SSB
- **Implied export value growth: +6.41% YoY** — (1−0.069)×(1+0.143)−1; price×volume proxy

## Scenario model
`74.98 × 28,444 × 1,000 × (1 + shock/100)`. Uses observed week-44 price and tonnes; value proxy is not realised revenue. The slider does not update the observed figures. Bounds: -25–25, step 1. All scenario outputs are hypothetical.

## Transmission hypothesis
The price decline offsets part of fresh salmon volume expansion; export value is a product, not a volume story. Drivers: export price, shipped tonnes, feed and energy costs, currency conversion. No estimated lag, correlation, backtest or counterfactual attribution.

## Falsification
Net realised margins rise despite weaker export prices through cost or FX improvements.

## Sources
- [SSB weekly salmon exports, 4 Nov 2026](https://www.ssb.no/en/utenriksokonomi/utenrikshandel/statistikk/eksport-av-laks)

## Methodological caveats
Small manually verified release extracts; do not extrapolate to populations or make firm-level investment decisions without microdata.


## Dimensional audit and independent scenario drivers

The original magnitude bars were removed because different units cannot be compared on a common axis. The added two-factor grid varies independent **hypothetical** drivers, without implying that the input values were sampled or calibrated.

Price and tonnes are independently varied around the observed week-44 baseline. Value proxy is not producer revenue or operating profit.

The grid is a deterministic sensitivity illustration, not an econometric estimate. No causal, lead–lag, predictive, sectoral or cross-sectional claims can be validated from the current release snapshots. Replication requires the cited source releases and the stated arithmetic assumptions.
