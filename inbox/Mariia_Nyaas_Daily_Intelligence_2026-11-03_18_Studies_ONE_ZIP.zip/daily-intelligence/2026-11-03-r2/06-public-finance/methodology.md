# Methodology — Automatic Stabilisers Before the Tax Base Turns

## Provenance
- **Euro area unemployment rate:** 6.5 % (2026-09). Eurostat: https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- **EU unemployment rate:** 6.2 % (2026-09). Eurostat: https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- **Euro area unemployed persons:** 11.555 million (2026-09). Eurostat: https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- **EU unemployed persons:** 13.773 million (2026-09). Eurostat: https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- **Euro area annual unemployment increase:** 420 thousand (2026-09). Eurostat: https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- **EU annual unemployment increase:** 471 thousand (2026-09). Eurostat: https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- **Euro area youth unemployment rate:** 15.4 % (2026-09). Eurostat: https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- **Euro area Q3 GDP quarterly growth:** 0.4 % (2026-Q3). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap

## Model
`a*b*c/1e6` where a, b, c are the three user-controlled inputs in order. Units are explicitly stated on the dashboard. No statistical estimation, causal identification or backtest is performed. The displayed sensitivity heatmap varies the second and third inputs by ±20%, subject to input bounds.

## Limitations and falsification
Eligibility, employment transitions and programme rules differ by country.

Source vintages may be revised. Aggregate series and supervisory scenarios cannot be interpreted as borrower-level or institution-level predictions. No observed relationship is inferred from a synthetic scenario grid.
