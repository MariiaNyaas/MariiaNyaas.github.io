# Automatic Stabilisers Before the Tax Base Turns

**Discipline:** Public Finance Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r2/06-public-finance/

Unemployment counts rose despite little movement in headline rates; evaluate the potential expenditure exposure under a benefits-sensitivity assumption.

## Evidence
- Euro area unemployment rate: 6.5 %, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- EU unemployment rate: 6.2 %, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- Euro area unemployed persons: 11.555 million, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- EU unemployed persons: 13.773 million, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- Euro area annual unemployment increase: 420 thousand, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- EU annual unemployment increase: 471 thousand, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- Euro area youth unemployment rate: 15.4 %, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- Euro area Q3 GDP quarterly growth: 0.4 %, 2026-Q3 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap

## Management implication
Separate automatic-stabiliser sensitivity from forecasted public spending.

## Limitation
Eligibility, employment transitions and programme rules differ by country.

The interactive sensitivity model is an illustrative calculation, not a forecast.
