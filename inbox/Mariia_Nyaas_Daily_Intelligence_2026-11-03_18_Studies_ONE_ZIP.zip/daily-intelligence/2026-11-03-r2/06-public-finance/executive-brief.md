# Executive brief — Automatic Stabilisers Before the Tax Base Turns

**Question.** Unemployment counts rose despite little movement in headline rates; evaluate the potential expenditure exposure under a benefits-sensitivity assumption.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Euro area unemployment rate: 6.5 % (2026-09); EU unemployment rate: 6.2 % (2026-09); Euro area unemployed persons: 11.555 million (2026-09); EU unemployed persons: 13.773 million (2026-09).

**Decision.** Separate automatic-stabiliser sensitivity from forecasted public spending.

**What would invalidate the interpretation?** Eligibility, employment transitions and programme rules differ by country.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
