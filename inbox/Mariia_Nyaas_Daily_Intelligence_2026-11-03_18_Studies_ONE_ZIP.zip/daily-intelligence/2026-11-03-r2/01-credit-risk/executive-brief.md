# Executive brief — Employment Stability Masks a Rising Default Pipeline

**Question.** An unchanged headline unemployment rate can coexist with a rising stock of jobseekers. Reconcile levels and rates before adjusting PD overlays.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Euro area unemployment rate: 6.5 % (2026-09); EU unemployment rate: 6.2 % (2026-09); Euro area unemployed persons: 11.555 million (2026-09); EU unemployed persons: 13.773 million (2026-09).

**Decision.** Trigger cohort-level migration analysis before relaxing underwriting.

**What would invalidate the interpretation?** If rising jobseeker counts are entirely seasonal or population-driven, the credit signal weakens.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
