# Executive brief — The Labour-Market Lag in Bank Funding Plans

**Question.** Deposits may reprice or run off before labour weakness appears in NPL data. Quantify a funding bridge under simultaneous outflow and spread shock.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Euro area unemployment rate: 6.5 % (2026-09); EU unemployment rate: 6.2 % (2026-09); Euro area unemployed persons: 11.555 million (2026-09); EU unemployed persons: 13.773 million (2026-09).

**Decision.** Tie treasury liquidity contingency triggers to labour and household cashflow indicators.

**What would invalidate the interpretation?** Stable deposit stickiness and hedging could mute the effect.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
