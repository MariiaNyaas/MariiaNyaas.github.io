# The Labour-Market Lag in Bank Funding Plans

**Discipline:** Financial Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r2/02-financial/

Deposits may reprice or run off before labour weakness appears in NPL data. Quantify a funding bridge under simultaneous outflow and spread shock.

## Evidence
- Euro area unemployment rate: 6.5 %, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- EU unemployment rate: 6.2 %, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- Euro area unemployed persons: 11.555 million, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- EU unemployed persons: 13.773 million, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- Euro area annual unemployment increase: 420 thousand, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- EU annual unemployment increase: 471 thousand, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- Euro area youth unemployment rate: 15.4 %, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- ECB policy decision: 0 change in policy rates, pp, 2026-10-29 — https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html

## Management implication
Tie treasury liquidity contingency triggers to labour and household cashflow indicators.

## Limitation
Stable deposit stickiness and hedging could mute the effect.

The interactive sensitivity model is an illustrative calculation, not a forecast.
