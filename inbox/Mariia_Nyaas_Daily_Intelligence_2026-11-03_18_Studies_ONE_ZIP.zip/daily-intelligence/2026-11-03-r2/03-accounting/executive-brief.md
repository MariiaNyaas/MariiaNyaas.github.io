# Executive brief — The Income–Consumption Reconciliation Audit

**Question.** Income and consumption growth diverged in the latest European sector accounts. Use the divergence to challenge assumptions in revenue recognition and demand forecasts.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Euro area real income per capita quarterly growth: 0.1 % (2026-Q2); Euro area real consumption per capita quarterly growth: 0.3 % (2026-Q2); Euro area household saving rate: 14.2 % (2026-Q2); Euro area saving rate quarterly change: -0.2 pp (2026-Q2).

**Decision.** Demand corroborating external evidence for revenue forecasts and impairment assumptions.

**What would invalidate the interpretation?** Product mix and firm-specific demand may diverge from aggregate consumption.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
