# The Income–Consumption Reconciliation Audit

**Discipline:** Accounting & Audit Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r2/03-accounting/

Income and consumption growth diverged in the latest European sector accounts. Use the divergence to challenge assumptions in revenue recognition and demand forecasts.

## Evidence
- Euro area real income per capita quarterly growth: 0.1 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Euro area real consumption per capita quarterly growth: 0.3 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Euro area household saving rate: 14.2 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Euro area saving rate quarterly change: -0.2 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Finland household saving rate quarterly change: -1.6 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Denmark household saving rate quarterly change: -0.9 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Sweden household saving rate quarterly change: -0.1 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- EU real consumption per capita quarterly growth: 0.4 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap

## Management implication
Demand corroborating external evidence for revenue forecasts and impairment assumptions.

## Limitation
Product mix and firm-specific demand may diverge from aggregate consumption.

The interactive sensitivity model is an illustrative calculation, not a forecast.
