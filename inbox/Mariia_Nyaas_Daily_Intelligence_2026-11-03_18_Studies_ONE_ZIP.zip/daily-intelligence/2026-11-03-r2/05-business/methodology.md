# Methodology — The Nordic Export Demand Wedge

## Provenance
- **Euro area Q3 GDP quarterly growth:** 0.4 % (2026-Q3). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- **EU Q3 GDP quarterly growth:** 0.5 % (2026-Q3). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- **Euro area Q2 GDP quarterly growth (revised):** 0.6 % (2026-Q3). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- **EU Q2 GDP quarterly growth (revised):** 0.7 % (2026-Q3). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- **Euro area Q3 GDP annual growth:** 1.3 % (2026-Q3). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- **EU Q3 GDP annual growth:** 1.5 % (2026-Q3). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- **Euro area real income per capita quarterly growth:** 0.1 % (2026-Q2). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- **Euro area real consumption per capita quarterly growth:** 0.3 % (2026-Q2). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap

## Model
`a*(b/100*(0.5-0.4)+(1-b/100)*(0.4-0.5))*c/100` where a, b, c are the three user-controlled inputs in order. Units are explicitly stated on the dashboard. No statistical estimation, causal identification or backtest is performed. The displayed sensitivity heatmap varies the second and third inputs by ±20%, subject to input bounds.

## Limitations and falsification
Industry-specific import demand and FX effects can dominate GDP signals.

Source vintages may be revised. Aggregate series and supervisory scenarios cannot be interpreted as borrower-level or institution-level predictions. No observed relationship is inferred from a synthetic scenario grid.
