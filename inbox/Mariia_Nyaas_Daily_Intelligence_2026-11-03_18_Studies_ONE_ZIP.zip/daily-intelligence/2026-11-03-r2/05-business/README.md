# The Nordic Export Demand Wedge

**Discipline:** Business & Economic Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r2/05-business/

EU quarterly growth exceeds euro area growth; compare how a Nordic exporter’s destination mix can amplify the difference.

## Evidence
- Euro area Q3 GDP quarterly growth: 0.4 %, 2026-Q3 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- EU Q3 GDP quarterly growth: 0.5 %, 2026-Q3 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- Euro area Q2 GDP quarterly growth (revised): 0.6 %, 2026-Q3 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- EU Q2 GDP quarterly growth (revised): 0.7 %, 2026-Q3 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- Euro area Q3 GDP annual growth: 1.3 %, 2026-Q3 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- EU Q3 GDP annual growth: 1.5 %, 2026-Q3 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- Euro area real income per capita quarterly growth: 0.1 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Euro area real consumption per capita quarterly growth: 0.3 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap

## Management implication
Map actual customer geography before extrapolating euro area GDP into sales.

## Limitation
Industry-specific import demand and FX effects can dominate GDP signals.

The interactive sensitivity model is an illustrative calculation, not a forecast.
