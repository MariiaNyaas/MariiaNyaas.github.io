# Executive brief — The Nordic Export Demand Wedge

**Question.** EU quarterly growth exceeds euro area growth; compare how a Nordic exporter’s destination mix can amplify the difference.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Euro area Q3 GDP quarterly growth: 0.4 % (2026-Q3); EU Q3 GDP quarterly growth: 0.5 % (2026-Q3); Euro area Q2 GDP quarterly growth (revised): 0.6 % (2026-Q3); EU Q2 GDP quarterly growth (revised): 0.7 % (2026-Q3).

**Decision.** Map actual customer geography before extrapolating euro area GDP into sales.

**What would invalidate the interpretation?** Industry-specific import demand and FX effects can dominate GDP signals.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
