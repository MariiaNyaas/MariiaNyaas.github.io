# The Concentration Amplifier in Outsourced Banking Operations

**Discipline:** Risk & Governance Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r2/04-governance/

A third-party outage can become a liquidity problem when concentration and processing backlog interact nonlinearly.

## Evidence
- Norwegian bank aggregate CET1 starting ratio: 17.82 % in 2025, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Norwegian bank aggregate stressed CET1 trough: 13.48 % in 2029, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stress lending rate start: 6.2 % in 2025, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stress lending rate end: 9.4 % in 2028, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stressed peak loan losses to assets: 1.59 % in 2028, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stressed pre-tax ROA trough: -0.76 % in 2028, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stress oil price 2027: 136 USD/bbl, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Euro area unemployment rate: 6.5 %, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp

## Management implication
Add concentration-weighted backlog metrics to ICT continuity dashboards.

## Limitation
Fallback rails and batching capacity could materially reduce disruption.

The interactive sensitivity model is an illustrative calculation, not a forecast.
