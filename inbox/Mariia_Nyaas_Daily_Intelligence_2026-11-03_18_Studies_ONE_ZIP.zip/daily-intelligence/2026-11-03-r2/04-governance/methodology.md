# Methodology — The Concentration Amplifier in Outsourced Banking Operations

## Provenance
- **Norwegian bank aggregate CET1 starting ratio:** 17.82 % in 2025 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Norwegian bank aggregate stressed CET1 trough:** 13.48 % in 2029 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Stress lending rate start:** 6.2 % in 2025 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Stress lending rate end:** 9.4 % in 2028 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Stressed peak loan losses to assets:** 1.59 % in 2028 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Stressed pre-tax ROA trough:** -0.76 % in 2028 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Stress oil price 2027:** 136 USD/bbl (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Euro area unemployment rate:** 6.5 % (2026-09). Eurostat: https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp

## Model
`a*b/100*Math.min(c,24)/24` where a, b, c are the three user-controlled inputs in order. Units are explicitly stated on the dashboard. No statistical estimation, causal identification or backtest is performed. The displayed sensitivity heatmap varies the second and third inputs by ±20%, subject to input bounds.

## Limitations and falsification
Fallback rails and batching capacity could materially reduce disruption.

Source vintages may be revised. Aggregate series and supervisory scenarios cannot be interpreted as borrower-level or institution-level predictions. No observed relationship is inferred from a synthetic scenario grid.
