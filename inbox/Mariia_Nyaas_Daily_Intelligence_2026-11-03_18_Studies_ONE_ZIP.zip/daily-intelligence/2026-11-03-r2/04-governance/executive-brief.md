# Executive brief — The Concentration Amplifier in Outsourced Banking Operations

**Question.** A third-party outage can become a liquidity problem when concentration and processing backlog interact nonlinearly.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Norwegian bank aggregate CET1 starting ratio: 17.82 % in 2025 (2026-06); Norwegian bank aggregate stressed CET1 trough: 13.48 % in 2029 (2026-06); Stress lending rate start: 6.2 % in 2025 (2026-06); Stress lending rate end: 9.4 % in 2028 (2026-06).

**Decision.** Add concentration-weighted backlog metrics to ICT continuity dashboards.

**What would invalidate the interpretation?** Fallback rails and batching capacity could materially reduce disruption.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
