# Executive brief — Model Overlays Under Contradictory Labour Signals

**Question.** A stable unemployment rate alongside rising unemployment counts creates model-governance risk if overlays respond to only one series.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Euro area unemployment rate: 6.5 % (2026-09); EU unemployment rate: 6.2 % (2026-09); Euro area unemployed persons: 11.555 million (2026-09); EU unemployed persons: 13.773 million (2026-09).

**Decision.** Require documented signal hierarchy and challenger tests for macro overlays.

**What would invalidate the interpretation?** The count-rate discrepancy may be definitional or population-driven.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
