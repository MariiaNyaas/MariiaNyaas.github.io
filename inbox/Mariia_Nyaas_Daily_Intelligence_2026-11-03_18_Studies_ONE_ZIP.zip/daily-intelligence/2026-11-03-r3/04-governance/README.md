# Model Overlays Under Contradictory Labour Signals

**Discipline:** Risk & Governance Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r3/04-governance/

A stable unemployment rate alongside rising unemployment counts creates model-governance risk if overlays respond to only one series.

## Evidence
- Euro area unemployment rate: 6.5 %, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- EU unemployment rate: 6.2 %, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- Euro area unemployed persons: 11.555 million, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- EU unemployed persons: 13.773 million, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- Euro area annual unemployment increase: 420 thousand, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- EU annual unemployment increase: 471 thousand, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- Euro area youth unemployment rate: 15.4 %, 2026-09 — https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/3-30102026-bp
- Euro area real income per capita quarterly growth: 0.1 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap

## Management implication
Require documented signal hierarchy and challenger tests for macro overlays.

## Limitation
The count-rate discrepancy may be definitional or population-driven.

The interactive sensitivity model is an illustrative calculation, not a forecast.
