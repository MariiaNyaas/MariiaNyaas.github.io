# Finland’s Savings Drawdown as a Consumer-Credit Signal

**Discipline:** Credit Risk Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r3/01-credit-risk/

Finland’s household saving-rate change is sharper than Sweden’s; test whether consumption is being financed by buffer depletion rather than income growth.

## Evidence
- Euro area real income per capita quarterly growth: 0.1 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Euro area real consumption per capita quarterly growth: 0.3 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Euro area household saving rate: 14.2 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Euro area saving rate quarterly change: -0.2 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Finland household saving rate quarterly change: -1.6 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Denmark household saving rate quarterly change: -0.9 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Sweden household saving rate quarterly change: -0.1 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- EU real consumption per capita quarterly growth: 0.4 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap

## Management implication
Monitor Finnish repayment behaviour and liquidity buffers by income band.

## Limitation
A temporary statistical revision or improved household confidence would weaken the interpretation.

The interactive sensitivity model is an illustrative calculation, not a forecast.
