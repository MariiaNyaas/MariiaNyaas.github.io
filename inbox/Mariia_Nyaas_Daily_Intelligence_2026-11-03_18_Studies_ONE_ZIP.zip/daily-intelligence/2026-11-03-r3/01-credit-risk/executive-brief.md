# Executive brief — Finland’s Savings Drawdown as a Consumer-Credit Signal

**Question.** Finland’s household saving-rate change is sharper than Sweden’s; test whether consumption is being financed by buffer depletion rather than income growth.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Euro area real income per capita quarterly growth: 0.1 % (2026-Q2); Euro area real consumption per capita quarterly growth: 0.3 % (2026-Q2); Euro area household saving rate: 14.2 % (2026-Q2); Euro area saving rate quarterly change: -0.2 pp (2026-Q2).

**Decision.** Monitor Finnish repayment behaviour and liquidity buffers by income band.

**What would invalidate the interpretation?** A temporary statistical revision or improved household confidence would weaken the interpretation.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
