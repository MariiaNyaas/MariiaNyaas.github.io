# The Nordic Rate Corridor and FX Hedge Compression

**Discipline:** Financial Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r3/02-financial/

A high Norwegian policy rate and unchanged ECB rates do not mechanically translate into FX returns; hedge carry and basis can dominate.

## Evidence
- Norges Bank policy rate: 4.5 %, 2026-09-24 — https://www.norges-bank.no/en/news-events/news/Press-releases/2026/2026-09-24-rate/
- September policy rate increase: 0.25 pp, 2026-09-24 — https://www.norges-bank.no/en/news-events/news/Press-releases/2026/2026-09-24-rate/
- ECB policy decision: 0 change in policy rates, pp, 2026-10-29 — https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html

## Management implication
Require currency-hedged attribution before comparing cross-border asset yields.

## Limitation
Forward pricing and realised basis may offset the nominal policy-rate gap.

The interactive sensitivity model is an illustrative calculation, not a forecast.
