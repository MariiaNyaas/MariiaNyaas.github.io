# Executive brief — The Nordic Rate Corridor and FX Hedge Compression

**Question.** A high Norwegian policy rate and unchanged ECB rates do not mechanically translate into FX returns; hedge carry and basis can dominate.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Norges Bank policy rate: 4.5 % (2026-09-24); September policy rate increase: 0.25 pp (2026-09-24); ECB policy decision: 0 change in policy rates, pp (2026-10-29).

**Decision.** Require currency-hedged attribution before comparing cross-border asset yields.

**What would invalidate the interpretation?** Forward pricing and realised basis may offset the nominal policy-rate gap.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
