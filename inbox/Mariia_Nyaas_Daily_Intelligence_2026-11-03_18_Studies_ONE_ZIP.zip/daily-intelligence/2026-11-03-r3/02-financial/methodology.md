# Methodology — The Nordic Rate Corridor and FX Hedge Compression

## Provenance
- **Norges Bank policy rate:** 4.5 % (2026-09-24). Norges Bank: https://www.norges-bank.no/en/news-events/news/Press-releases/2026/2026-09-24-rate/
- **September policy rate increase:** 0.25 pp (2026-09-24). Norges Bank: https://www.norges-bank.no/en/news-events/news/Press-releases/2026/2026-09-24-rate/
- **ECB policy decision:** 0 change in policy rates, pp (2026-10-29). European Central Bank: https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html

## Model
`a*(b-c)/100` where a, b, c are the three user-controlled inputs in order. Units are explicitly stated on the dashboard. No statistical estimation, causal identification or backtest is performed. The displayed sensitivity heatmap varies the second and third inputs by ±20%, subject to input bounds.

## Limitations and falsification
Forward pricing and realised basis may offset the nominal policy-rate gap.

Source vintages may be revised. Aggregate series and supervisory scenarios cannot be interpreted as borrower-level or institution-level predictions. No observed relationship is inferred from a synthetic scenario grid.
