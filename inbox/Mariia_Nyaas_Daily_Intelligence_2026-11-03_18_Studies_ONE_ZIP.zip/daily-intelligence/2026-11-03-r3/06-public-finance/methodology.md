# Methodology — The Nordic Tax-Base Elasticity to Consumer Demand

## Provenance
- **Euro area real income per capita quarterly growth:** 0.1 % (2026-Q2). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- **Euro area real consumption per capita quarterly growth:** 0.3 % (2026-Q2). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- **Euro area household saving rate:** 14.2 % (2026-Q2). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- **Euro area saving rate quarterly change:** -0.2 pp (2026-Q2). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- **Finland household saving rate quarterly change:** -1.6 pp (2026-Q2). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- **Denmark household saving rate quarterly change:** -0.9 pp (2026-Q2). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- **Sweden household saving rate quarterly change:** -0.1 pp (2026-Q2). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- **EU real consumption per capita quarterly growth:** 0.4 % (2026-Q2). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap

## Model
`a*1000*b/100*c/100` where a, b, c are the three user-controlled inputs in order. Units are explicitly stated on the dashboard. No statistical estimation, causal identification or backtest is performed. The displayed sensitivity heatmap varies the second and third inputs by ±20%, subject to input bounds.

## Limitations and falsification
Exemptions, compliance, and the effective tax base may differ.

Source vintages may be revised. Aggregate series and supervisory scenarios cannot be interpreted as borrower-level or institution-level predictions. No observed relationship is inferred from a synthetic scenario grid.
