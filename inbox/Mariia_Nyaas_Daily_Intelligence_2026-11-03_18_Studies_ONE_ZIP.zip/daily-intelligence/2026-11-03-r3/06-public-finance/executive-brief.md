# Executive brief — The Nordic Tax-Base Elasticity to Consumer Demand

**Question.** Consumption may outpace income even as saving rates fall; explore a VAT sensitivity, explicitly avoiding a claim about actual tax receipts.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Euro area real income per capita quarterly growth: 0.1 % (2026-Q2); Euro area real consumption per capita quarterly growth: 0.3 % (2026-Q2); Euro area household saving rate: 14.2 % (2026-Q2); Euro area saving rate quarterly change: -0.2 pp (2026-Q2).

**Decision.** Stress budget receipts under weaker consumer demand and delayed tax settlement.

**What would invalidate the interpretation?** Exemptions, compliance, and the effective tax base may differ.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
