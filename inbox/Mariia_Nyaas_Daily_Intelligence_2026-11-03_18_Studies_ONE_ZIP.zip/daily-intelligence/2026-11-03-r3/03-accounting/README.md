# Going-Concern Stress: A Rate Shock Before an Earnings Shock

**Discipline:** Accounting & Audit Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r3/03-accounting/

The stressed lending rate increases markedly in the Norwegian supervisory scenario; test debt-service headroom before earnings deteriorate.

## Evidence
- Norwegian bank aggregate CET1 starting ratio: 17.82 % in 2025, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Norwegian bank aggregate stressed CET1 trough: 13.48 % in 2029, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stress lending rate start: 6.2 % in 2025, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stress lending rate end: 9.4 % in 2028, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stressed peak loan losses to assets: 1.59 % in 2028, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stressed pre-tax ROA trough: -0.76 % in 2028, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stress oil price 2027: 136 USD/bbl, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Norges Bank policy rate: 4.5 %, 2026-09-24 — https://www.norges-bank.no/en/news-events/news/Press-releases/2026/2026-09-24-rate/

## Management implication
Challenge covenant forecasts and subsequent-events disclosures with sensitivity cases.

## Limitation
Refinancing terms and fixed-rate hedges can materially alter the result.

The interactive sensitivity model is an illustrative calculation, not a forecast.
