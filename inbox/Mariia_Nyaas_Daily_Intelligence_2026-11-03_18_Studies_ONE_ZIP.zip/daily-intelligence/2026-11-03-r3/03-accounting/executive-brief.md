# Executive brief — Going-Concern Stress: A Rate Shock Before an Earnings Shock

**Question.** The stressed lending rate increases markedly in the Norwegian supervisory scenario; test debt-service headroom before earnings deteriorate.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Norwegian bank aggregate CET1 starting ratio: 17.82 % in 2025 (2026-06); Norwegian bank aggregate stressed CET1 trough: 13.48 % in 2029 (2026-06); Stress lending rate start: 6.2 % in 2025 (2026-06); Stress lending rate end: 9.4 % in 2028 (2026-06).

**Decision.** Challenge covenant forecasts and subsequent-events disclosures with sensitivity cases.

**What would invalidate the interpretation?** Refinancing terms and fixed-rate hedges can materially alter the result.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
