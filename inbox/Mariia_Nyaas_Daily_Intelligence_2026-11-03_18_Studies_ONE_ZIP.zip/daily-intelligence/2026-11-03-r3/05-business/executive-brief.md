# Executive brief — Consumption Resilience Versus Savings Depletion

**Question.** A consumption rebound with slower income growth can support near-term sales while weakening future spending capacity.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Euro area real income per capita quarterly growth: 0.1 % (2026-Q2); Euro area real consumption per capita quarterly growth: 0.3 % (2026-Q2); Euro area household saving rate: 14.2 % (2026-Q2); Euro area saving rate quarterly change: -0.2 pp (2026-Q2).

**Decision.** Use household buffers as a counterweight to optimistic near-term sales extrapolation.

**What would invalidate the interpretation?** Higher productivity or wages could sustain consumption despite a saving-rate decline.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
