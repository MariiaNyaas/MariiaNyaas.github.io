# Consumption Resilience Versus Savings Depletion

**Discipline:** Business & Economic Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r3/05-business/

A consumption rebound with slower income growth can support near-term sales while weakening future spending capacity.

## Evidence
- Euro area real income per capita quarterly growth: 0.1 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Euro area real consumption per capita quarterly growth: 0.3 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Euro area household saving rate: 14.2 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Euro area saving rate quarterly change: -0.2 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Finland household saving rate quarterly change: -1.6 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Denmark household saving rate quarterly change: -0.9 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Sweden household saving rate quarterly change: -0.1 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- EU real consumption per capita quarterly growth: 0.4 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap

## Management implication
Use household buffers as a counterweight to optimistic near-term sales extrapolation.

## Limitation
Higher productivity or wages could sustain consumption despite a saving-rate decline.

The interactive sensitivity model is an illustrative calculation, not a forecast.
