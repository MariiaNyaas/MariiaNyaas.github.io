# Executive brief — The Norwegian Cost Basket That Headline CPI Hides

**Question.** Insurance, hospitality and transport inflation are well above underlying CPI, creating sector-specific pressure on SME operating leverage.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Norway headline CPI inflation: 3.4 % YoY (2026-09); Norway underlying CPI-ATE inflation: 3.0 % YoY (2026-09); Norway transport inflation: 4.8 % YoY (2026-09); Norway insurance and financial services inflation: 7.9 % YoY (2026-09).

**Decision.** Stress gross margin by supplier category, not only aggregate CPI.

**What would invalidate the interpretation?** Supplier contracts and pass-through pricing may insulate earnings.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
