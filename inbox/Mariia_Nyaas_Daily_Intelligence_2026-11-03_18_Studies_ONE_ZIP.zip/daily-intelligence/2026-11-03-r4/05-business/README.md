# The Norwegian Cost Basket That Headline CPI Hides

**Discipline:** Business & Economic Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r4/05-business/

Insurance, hospitality and transport inflation are well above underlying CPI, creating sector-specific pressure on SME operating leverage.

## Evidence
- Norway headline CPI inflation: 3.4 % YoY, 2026-09 — https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- Norway underlying CPI-ATE inflation: 3.0 % YoY, 2026-09 — https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- Norway transport inflation: 4.8 % YoY, 2026-09 — https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- Norway insurance and financial services inflation: 7.9 % YoY, 2026-09 — https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- Norway restaurants and accommodation inflation: 6.0 % YoY, 2026-09 — https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- Norway health inflation: 4.9 % YoY, 2026-09 — https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- Euro area Q3 GDP quarterly growth: 0.4 %, 2026-Q3 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- EU Q3 GDP quarterly growth: 0.5 %, 2026-Q3 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap

## Management implication
Stress gross margin by supplier category, not only aggregate CPI.

## Limitation
Supplier contracts and pass-through pricing may insulate earnings.

The interactive sensitivity model is an illustrative calculation, not a forecast.
