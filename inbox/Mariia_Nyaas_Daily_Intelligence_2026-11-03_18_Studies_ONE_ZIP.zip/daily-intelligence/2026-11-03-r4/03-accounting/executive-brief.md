# Executive brief — Audit Materiality Under Inflation-Driven Revenue Growth

**Question.** Nominal growth can inflate materiality benchmarks while underlying volumes stagnate. Test the impact on undetected-error tolerance.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Norway headline CPI inflation: 3.4 % YoY (2026-09); Norway underlying CPI-ATE inflation: 3.0 % YoY (2026-09); Norway transport inflation: 4.8 % YoY (2026-09); Norway insurance and financial services inflation: 7.9 % YoY (2026-09).

**Decision.** Cross-check revenue-based materiality against operating profit and inflation-adjusted activity.

**What would invalidate the interpretation?** Real growth and company-specific cost structures may differ.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
