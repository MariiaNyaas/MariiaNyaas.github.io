# Methodology — Audit Materiality Under Inflation-Driven Revenue Growth

## Provenance
- **Norway headline CPI inflation:** 3.4 % YoY (2026-09). Statistics Norway: https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- **Norway underlying CPI-ATE inflation:** 3.0 % YoY (2026-09). Statistics Norway: https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- **Norway transport inflation:** 4.8 % YoY (2026-09). Statistics Norway: https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- **Norway insurance and financial services inflation:** 7.9 % YoY (2026-09). Statistics Norway: https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- **Norway restaurants and accommodation inflation:** 6.0 % YoY (2026-09). Statistics Norway: https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- **Norway health inflation:** 4.9 % YoY (2026-09). Statistics Norway: https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- **Euro area Q3 GDP quarterly growth:** 0.4 % (2026-Q3). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- **EU Q3 GDP quarterly growth:** 0.5 % (2026-Q3). Eurostat: https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap

## Model
`a*b/100/(1+c/100)` where a, b, c are the three user-controlled inputs in order. Units are explicitly stated on the dashboard. No statistical estimation, causal identification or backtest is performed. The displayed sensitivity heatmap varies the second and third inputs by ±20%, subject to input bounds.

## Limitations and falsification
Real growth and company-specific cost structures may differ.

Source vintages may be revised. Aggregate series and supervisory scenarios cannot be interpreted as borrower-level or institution-level predictions. No observed relationship is inferred from a synthetic scenario grid.
