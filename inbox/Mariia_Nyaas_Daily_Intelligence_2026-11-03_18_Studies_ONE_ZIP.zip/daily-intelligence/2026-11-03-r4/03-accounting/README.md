# Audit Materiality Under Inflation-Driven Revenue Growth

**Discipline:** Accounting & Audit Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r4/03-accounting/

Nominal growth can inflate materiality benchmarks while underlying volumes stagnate. Test the impact on undetected-error tolerance.

## Evidence
- Norway headline CPI inflation: 3.4 % YoY, 2026-09 — https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- Norway underlying CPI-ATE inflation: 3.0 % YoY, 2026-09 — https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- Norway transport inflation: 4.8 % YoY, 2026-09 — https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- Norway insurance and financial services inflation: 7.9 % YoY, 2026-09 — https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- Norway restaurants and accommodation inflation: 6.0 % YoY, 2026-09 — https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- Norway health inflation: 4.9 % YoY, 2026-09 — https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/
- Euro area Q3 GDP quarterly growth: 0.4 %, 2026-Q3 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- EU Q3 GDP quarterly growth: 0.5 %, 2026-Q3 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap

## Management implication
Cross-check revenue-based materiality against operating profit and inflation-adjusted activity.

## Limitation
Real growth and company-specific cost structures may differ.

The interactive sensitivity model is an illustrative calculation, not a forecast.
