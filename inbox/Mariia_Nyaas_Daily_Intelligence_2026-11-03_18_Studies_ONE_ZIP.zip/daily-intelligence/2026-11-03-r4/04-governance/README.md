# Reverse Stress Testing Norway’s Capital Buffer

**Discipline:** Risk & Governance Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r4/04-governance/

Use the regulator’s aggregate CET1 stress trough as a boundary condition, not a forecast, to explore additional loss absorption.

## Evidence
- Norwegian bank aggregate CET1 starting ratio: 17.82 % in 2025, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Norwegian bank aggregate stressed CET1 trough: 13.48 % in 2029, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stress lending rate start: 6.2 % in 2025, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stress lending rate end: 9.4 % in 2028, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stressed peak loan losses to assets: 1.59 % in 2028, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stressed pre-tax ROA trough: -0.76 % in 2028, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stress oil price 2027: 136 USD/bbl, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Norges Bank policy rate: 4.5 %, 2026-09-24 — https://www.norges-bank.no/en/news-events/news/Press-releases/2026/2026-09-24-rate/

## Management implication
Set early intervention triggers above the management floor with uncertainty margins.

## Limitation
Bank-level balance sheets differ materially from the supervisory aggregate.

The interactive sensitivity model is an illustrative calculation, not a forecast.
