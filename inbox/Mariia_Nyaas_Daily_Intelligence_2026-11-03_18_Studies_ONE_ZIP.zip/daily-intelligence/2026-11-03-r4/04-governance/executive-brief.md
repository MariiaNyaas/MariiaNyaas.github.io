# Executive brief — Reverse Stress Testing Norway’s Capital Buffer

**Question.** Use the regulator’s aggregate CET1 stress trough as a boundary condition, not a forecast, to explore additional loss absorption.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Norwegian bank aggregate CET1 starting ratio: 17.82 % in 2025 (2026-06); Norwegian bank aggregate stressed CET1 trough: 13.48 % in 2029 (2026-06); Stress lending rate start: 6.2 % in 2025 (2026-06); Stress lending rate end: 9.4 % in 2028 (2026-06).

**Decision.** Set early intervention triggers above the management floor with uncertainty margins.

**What would invalidate the interpretation?** Bank-level balance sheets differ materially from the supervisory aggregate.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
