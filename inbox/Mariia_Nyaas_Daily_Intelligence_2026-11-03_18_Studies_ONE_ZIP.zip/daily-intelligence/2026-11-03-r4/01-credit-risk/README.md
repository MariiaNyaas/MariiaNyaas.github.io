# Nordic Real-Income and Consumption Divergence

**Discipline:** Credit Risk Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r4/01-credit-risk/

Euro area real consumption growth outpaced real income growth in Q2; investigate how spending resilience can conceal declining buffers.

## Evidence
- Euro area real income per capita quarterly growth: 0.1 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Euro area real consumption per capita quarterly growth: 0.3 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Euro area household saving rate: 14.2 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Euro area saving rate quarterly change: -0.2 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Finland household saving rate quarterly change: -1.6 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Denmark household saving rate quarterly change: -0.9 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- Sweden household saving rate quarterly change: -0.1 pp, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap
- EU real consumption per capita quarterly growth: 0.4 %, 2026-Q2 — https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-28102026-ap

## Management implication
Use segmented affordability floors rather than headline inflation alone.

## Limitation
If wages or transfers fully offset the category shock, buffer erosion may not occur.

The interactive sensitivity model is an illustrative calculation, not a forecast.
