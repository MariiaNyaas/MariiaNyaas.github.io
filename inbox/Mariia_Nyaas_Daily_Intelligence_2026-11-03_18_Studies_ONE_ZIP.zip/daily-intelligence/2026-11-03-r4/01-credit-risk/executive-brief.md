# Executive brief — Nordic Real-Income and Consumption Divergence

**Question.** Euro area real consumption growth outpaced real income growth in Q2; investigate how spending resilience can conceal declining buffers.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Euro area real income per capita quarterly growth: 0.1 % (2026-Q2); Euro area real consumption per capita quarterly growth: 0.3 % (2026-Q2); Euro area household saving rate: 14.2 % (2026-Q2); Euro area saving rate quarterly change: -0.2 pp (2026-Q2).

**Decision.** Use segmented affordability floors rather than headline inflation alone.

**What would invalidate the interpretation?** If wages or transfers fully offset the category shock, buffer erosion may not occur.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
