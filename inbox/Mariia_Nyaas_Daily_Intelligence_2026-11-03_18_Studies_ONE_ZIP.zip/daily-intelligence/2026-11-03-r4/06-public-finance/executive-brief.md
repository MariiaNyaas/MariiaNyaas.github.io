# Executive brief — Debt-Service Sensitivity to an Energy-Led Rate Shock

**Question.** ECB warned of energy-driven inflation and growth risks; examine how refinancing share and rate shocks interact in fiscal interest expenditure.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** ECB policy decision: 0 change in policy rates, pp (2026-10-29); Norges Bank policy rate: 4.5 % (2026-09-24); September policy rate increase: 0.25 pp (2026-09-24); Norwegian bank aggregate CET1 starting ratio: 17.82 % in 2025 (2026-06).

**Decision.** Monitor maturity structure, not only the stock of public debt, when assessing fiscal headroom.

**What would invalidate the interpretation?** Debt issuance, cash buffers and central-bank remittances affect realised interest costs.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
