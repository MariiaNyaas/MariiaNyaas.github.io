# Debt-Service Sensitivity to an Energy-Led Rate Shock

**Discipline:** Public Finance Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r4/06-public-finance/

ECB warned of energy-driven inflation and growth risks; examine how refinancing share and rate shocks interact in fiscal interest expenditure.

## Evidence
- ECB policy decision: 0 change in policy rates, pp, 2026-10-29 — https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html
- Norges Bank policy rate: 4.5 %, 2026-09-24 — https://www.norges-bank.no/en/news-events/news/Press-releases/2026/2026-09-24-rate/
- September policy rate increase: 0.25 pp, 2026-09-24 — https://www.norges-bank.no/en/news-events/news/Press-releases/2026/2026-09-24-rate/
- Norwegian bank aggregate CET1 starting ratio: 17.82 % in 2025, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Norwegian bank aggregate stressed CET1 trough: 13.48 % in 2029, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stress lending rate start: 6.2 % in 2025, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stress lending rate end: 9.4 % in 2028, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stressed peak loan losses to assets: 1.59 % in 2028, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/

## Management implication
Monitor maturity structure, not only the stock of public debt, when assessing fiscal headroom.

## Limitation
Debt issuance, cash buffers and central-bank remittances affect realised interest costs.

The interactive sensitivity model is an illustrative calculation, not a forecast.
