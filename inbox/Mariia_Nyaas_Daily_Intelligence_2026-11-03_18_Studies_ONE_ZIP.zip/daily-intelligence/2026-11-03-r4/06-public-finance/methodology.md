# Methodology — Debt-Service Sensitivity to an Energy-Led Rate Shock

## Provenance
- **ECB policy decision:** 0 change in policy rates, pp (2026-10-29). European Central Bank: https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html
- **Norges Bank policy rate:** 4.5 % (2026-09-24). Norges Bank: https://www.norges-bank.no/en/news-events/news/Press-releases/2026/2026-09-24-rate/
- **September policy rate increase:** 0.25 pp (2026-09-24). Norges Bank: https://www.norges-bank.no/en/news-events/news/Press-releases/2026/2026-09-24-rate/
- **Norwegian bank aggregate CET1 starting ratio:** 17.82 % in 2025 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Norwegian bank aggregate stressed CET1 trough:** 13.48 % in 2029 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Stress lending rate start:** 6.2 % in 2025 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Stress lending rate end:** 9.4 % in 2028 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Stressed peak loan losses to assets:** 1.59 % in 2028 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/

## Model
`a*b/100*c/100` where a, b, c are the three user-controlled inputs in order. Units are explicitly stated on the dashboard. No statistical estimation, causal identification or backtest is performed. The displayed sensitivity heatmap varies the second and third inputs by ±20%, subject to input bounds.

## Limitations and falsification
Debt issuance, cash buffers and central-bank remittances affect realised interest costs.

Source vintages may be revised. Aggregate series and supervisory scenarios cannot be interpreted as borrower-level or institution-level predictions. No observed relationship is inferred from a synthetic scenario grid.
