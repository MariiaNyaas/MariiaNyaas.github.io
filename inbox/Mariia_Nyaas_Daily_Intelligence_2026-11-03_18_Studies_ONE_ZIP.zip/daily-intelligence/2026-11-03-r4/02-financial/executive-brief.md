# Executive brief — Margin Resilience Versus Stressed Credit Cost

**Question.** Finanstilsynet’s scenario shows capital deterioration; isolate the point where a pricing margin fails to cover incremental expected credit losses.

**Why now.** The latest Eurostat releases of 28–30 October 2026 and recent Norwegian official statistics motivate an updated sensitivity exercise. Older Norges Bank and Finanstilsynet observations are clearly dated as context, not new releases.

**What the evidence establishes.** Norwegian bank aggregate CET1 starting ratio: 17.82 % in 2025 (2026-06); Norwegian bank aggregate stressed CET1 trough: 13.48 % in 2029 (2026-06); Stress lending rate start: 6.2 % in 2025 (2026-06); Stress lending rate end: 9.4 % in 2028 (2026-06).

**Decision.** Stress both NII and losses in the same capital allocation decision.

**What would invalidate the interpretation?** Credit quality, fee income and hedges can offset the simplified margin bridge.

**Caution.** This is an explanatory, parameterised scenario, not an empirically validated prediction.
