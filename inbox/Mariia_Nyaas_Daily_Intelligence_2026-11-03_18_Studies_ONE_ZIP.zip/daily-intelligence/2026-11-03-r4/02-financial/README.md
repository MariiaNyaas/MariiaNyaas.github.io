# Margin Resilience Versus Stressed Credit Cost

**Discipline:** Financial Intelligence  
**Published:** 2026-11-03  
**URL:** https://mariianyaas.github.io/daily-intelligence/2026-11-03-r4/02-financial/

Finanstilsynet’s scenario shows capital deterioration; isolate the point where a pricing margin fails to cover incremental expected credit losses.

## Evidence
- Norwegian bank aggregate CET1 starting ratio: 17.82 % in 2025, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Norwegian bank aggregate stressed CET1 trough: 13.48 % in 2029, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stress lending rate start: 6.2 % in 2025, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stress lending rate end: 9.4 % in 2028, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stressed peak loan losses to assets: 1.59 % in 2028, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stressed pre-tax ROA trough: -0.76 % in 2028, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Stress oil price 2027: 136 USD/bbl, 2026-06 — https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- Norges Bank policy rate: 4.5 %, 2026-09-24 — https://www.norges-bank.no/en/news-events/news/Press-releases/2026/2026-09-24-rate/

## Management implication
Stress both NII and losses in the same capital allocation decision.

## Limitation
Credit quality, fee income and hedges can offset the simplified margin bridge.

The interactive sensitivity model is an illustrative calculation, not a forecast.
