# Methodology — Margin Resilience Versus Stressed Credit Cost

## Provenance
- **Norwegian bank aggregate CET1 starting ratio:** 17.82 % in 2025 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Norwegian bank aggregate stressed CET1 trough:** 13.48 % in 2029 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Stress lending rate start:** 6.2 % in 2025 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Stress lending rate end:** 9.4 % in 2028 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Stressed peak loan losses to assets:** 1.59 % in 2028 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Stressed pre-tax ROA trough:** -0.76 % in 2028 (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Stress oil price 2027:** 136 USD/bbl (2026-06). Finanstilsynet: https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/
- **Norges Bank policy rate:** 4.5 % (2026-09-24). Norges Bank: https://www.norges-bank.no/en/news-events/news/Press-releases/2026/2026-09-24-rate/

## Model
`a*1000*(b-c)/100` where a, b, c are the three user-controlled inputs in order. Units are explicitly stated on the dashboard. No statistical estimation, causal identification or backtest is performed. The displayed sensitivity heatmap varies the second and third inputs by ±20%, subject to input bounds.

## Limitations and falsification
Credit quality, fee income and hedges can offset the simplified margin bridge.

Source vintages may be revised. Aggregate series and supervisory scenarios cannot be interpreted as borrower-level or institution-level predictions. No observed relationship is inferred from a synthetic scenario grid.
