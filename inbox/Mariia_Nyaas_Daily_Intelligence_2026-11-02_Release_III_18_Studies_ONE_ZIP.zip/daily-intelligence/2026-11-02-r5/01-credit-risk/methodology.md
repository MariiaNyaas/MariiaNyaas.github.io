# Methodology — From Bank Loan Loss to Capital Headroom

## Hypothesis and data
How much capital is consumed when a loss shock is applied to a balance-sheet proxy?

- **Norwegian stress bank loan losses / assets:** 1.59 % assets, period 2028 stress. Finanstilsynet. [Original release](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/).
- **Norwegian stressed NII / total assets, minimum:** 1.52 % assets, period 2028 stress. Finanstilsynet. [Original release](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/).

## Reproducible scenario
Inputs: Illustrative bank assets (NOK bn), Share exposed to stress loss rate (%). Equation: 1.59% stressed loss ratio × exposed-asset share. Output unit: NOK bn. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
Regulatory stressed ratios are not forecasts or bank-specific capital estimates. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
