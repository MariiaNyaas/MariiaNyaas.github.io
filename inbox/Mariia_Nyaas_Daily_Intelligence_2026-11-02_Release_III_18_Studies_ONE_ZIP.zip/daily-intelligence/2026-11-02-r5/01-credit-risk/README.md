# From Bank Loan Loss to Capital Headroom

Supervisor stress loss intensity can reveal vulnerability concealed by low current defaults.

Domain: Credit Risk Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r5/01-credit-risk/)

**Editorial question:** How much capital is consumed when a loss shock is applied to a balance-sheet proxy?

**Evidence:** Finanstilsynet, Finanstilsynet.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
