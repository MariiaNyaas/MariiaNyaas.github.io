# Executive brief | From Bank Loan Loss to Capital Headroom

**Signal.** Supervisor stress loss intensity can reveal vulnerability concealed by low current defaults.

**Decision question.** How much capital is consumed when a loss shock is applied to a balance-sheet proxy?

**Why it matters.** The observed indicators create a specific, testable challenge for risk or finance leadership. They are not proof of a company-level outcome.

**Quantitative illustration.** At initial inputs (100 NOK bn; 70 %), the output is 1.113 NOK bn. This is entirely scenario-derived and not an observed amount.

**Management response.** Compare first-loss absorption with internal capital triggers and management buffers.

**Challenge.** Regulatory stressed ratios are not forecasts or bank-specific capital estimates.

**Evidence:** [Finanstilsynet](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/) · [Finanstilsynet](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/)
