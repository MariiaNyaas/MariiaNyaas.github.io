# The EU Growth Premium and Nordic Allocation Choice

EU Q3 growth (+0.5%) exceeded euro-area growth (+0.4%).

Domain: Business & Economic Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r5/05-business/)

**Editorial question:** How does a small performance gap translate to revenue only under explicit sensitivity assumptions?

**Evidence:** Eurostat, Eurostat.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
