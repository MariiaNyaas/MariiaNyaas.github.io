# Methodology — The EU Growth Premium and Nordic Allocation Choice

## Hypothesis and data
How does a small performance gap translate to revenue only under explicit sensitivity assumptions?

- **EU GDP growth Q3:** 0.5 % QoQ, period 2026-Q3. Eurostat. [Original release](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap).
- **Euro area GDP growth Q3:** 0.4 % QoQ, period 2026-Q3. Eurostat. [Original release](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap).

## Reproducible scenario
Inputs: Illustrative regional sales (EUR m), Demand sensitivity coefficient (x). Equation: EU versus EA GDP gap of 0.1pp × elasticity × revenue. Output unit: EUR m. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
Single-quarter aggregate GDP differences are not returns or equity premia. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
