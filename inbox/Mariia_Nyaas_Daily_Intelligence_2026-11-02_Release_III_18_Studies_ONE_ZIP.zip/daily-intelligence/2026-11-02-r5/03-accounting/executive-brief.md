# Executive brief | A Stressed NII Estimate Needs an Evidence Chain

**Signal.** Supervisory NII paths offer a benchmark, not audit evidence for a bank’s own models.

**Decision question.** How much modeled earnings could be overstated if stress assumptions lag reality?

**Why it matters.** The observed indicators create a specific, testable challenge for risk or finance leadership. They are not proof of a company-level outcome.

**Quantitative illustration.** At initial inputs (3 NOK bn; 9 %), the output is 0.270 same monetary unit as exposure. This is entirely scenario-derived and not an observed amount.

**Management response.** Require independently recalculated inputs, ALM source-system reconciliation and model-version controls.

**Challenge.** Scenario overstatement is invented for control-testing illustration, not an audit finding.

**Evidence:** [Finanstilsynet](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/) · [Finanstilsynet](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/)
