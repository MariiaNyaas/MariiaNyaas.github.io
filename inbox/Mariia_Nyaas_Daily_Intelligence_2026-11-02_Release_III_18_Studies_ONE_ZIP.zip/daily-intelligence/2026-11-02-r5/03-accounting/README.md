# A Stressed NII Estimate Needs an Evidence Chain

Supervisory NII paths offer a benchmark, not audit evidence for a bank’s own models.

Domain: Accounting & Audit Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r5/03-accounting/)

**Editorial question:** How much modeled earnings could be overstated if stress assumptions lag reality?

**Evidence:** Finanstilsynet, Finanstilsynet.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
