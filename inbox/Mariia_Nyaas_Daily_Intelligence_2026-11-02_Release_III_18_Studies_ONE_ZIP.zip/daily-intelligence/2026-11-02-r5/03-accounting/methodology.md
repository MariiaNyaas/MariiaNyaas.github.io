# Methodology — A Stressed NII Estimate Needs an Evidence Chain

## Hypothesis and data
How much modeled earnings could be overstated if stress assumptions lag reality?

- **Norwegian bank NII / total assets:** 2.0 % assets, period 2025 actual. Finanstilsynet. [Original release](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/).
- **Norwegian stressed NII / total assets, minimum:** 1.52 % assets, period 2028 stress. Finanstilsynet. [Original release](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/).

## Reproducible scenario
Inputs: Illustrative reported NII (NOK bn), Assumption overstatement (%). Equation: expense base × assumed escalation. Output unit: same monetary unit as exposure. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
Scenario overstatement is invented for control-testing illustration, not an audit finding. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
