# Methodology — Intergovernmental Loans: The Hidden Fiscal Network

## Hypothesis and data
What notional amount does that ratio imply for an illustrative GDP base?

- **Euro area intergovernmental lending:** 1.3 % GDP, period 2026-Q2. Eurostat. [Original release](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-bp).
- **Euro area government debt:** 88.8 % GDP, period 2026-Q2. Eurostat. [Original release](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-bp).

## Reproducible scenario
Inputs: Illustrative GDP (EUR bn), Intergovernmental lending ratio (%). Equation: simple exposure × rate. Output unit: input currency units/year. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
Notional calculation uses a hypothetical GDP and should not be read as the euro-area absolute stock. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
