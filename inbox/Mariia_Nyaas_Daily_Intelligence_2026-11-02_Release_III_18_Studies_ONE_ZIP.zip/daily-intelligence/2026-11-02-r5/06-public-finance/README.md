# Intergovernmental Loans: The Hidden Fiscal Network

Euro-area intergovernmental lending is 1.3% of GDP.

Domain: Public Finance Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r5/06-public-finance/)

**Editorial question:** What notional amount does that ratio imply for an illustrative GDP base?

**Evidence:** Eurostat, Eurostat.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
