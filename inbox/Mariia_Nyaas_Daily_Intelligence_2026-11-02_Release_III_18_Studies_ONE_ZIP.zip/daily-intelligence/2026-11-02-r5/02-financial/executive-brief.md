# Executive brief | Net Interest Margin Drawdown Under Supervisory Stress

**Signal.** Norwegian bank NII/assets falls from 2.0% to 1.52% in supervisory stress.

**Decision question.** What operating-income capacity disappears before credit losses accelerate?

**Why it matters.** The observed indicators create a specific, testable challenge for risk or finance leadership. They are not proof of a company-level outcome.

**Quantitative illustration.** At initial inputs (150 NOK bn; 70 %), the output is 0.504 NOK bn/year. This is entirely scenario-derived and not an observed amount.

**Management response.** Reconcile stress NII erosion against funding duration, deposit pricing and management action.

**Challenge.** Supervisory aggregate stress is neither an individual bank forecast nor capital advice.

**Evidence:** [Finanstilsynet](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/) · [Finanstilsynet](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/)
