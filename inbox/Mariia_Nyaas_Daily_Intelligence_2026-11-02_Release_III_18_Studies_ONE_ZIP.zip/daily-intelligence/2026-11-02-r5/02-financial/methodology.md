# Methodology — Net Interest Margin Drawdown Under Supervisory Stress

## Hypothesis and data
What operating-income capacity disappears before credit losses accelerate?

- **Norwegian bank NII / total assets:** 2.0 % assets, period 2025 actual. Finanstilsynet. [Original release](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/).
- **Norwegian stressed NII / total assets, minimum:** 1.52 % assets, period 2028 stress. Finanstilsynet. [Original release](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/).

## Reproducible scenario
Inputs: Illustrative bank assets (NOK bn), Earnings retention ratio (%). Equation: (2.00%-1.52%) × assets × retained share. Output unit: NOK bn/year. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
Supervisory aggregate stress is neither an individual bank forecast nor capital advice. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
