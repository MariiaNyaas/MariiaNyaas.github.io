# Net Interest Margin Drawdown Under Supervisory Stress

Norwegian bank NII/assets falls from 2.0% to 1.52% in supervisory stress.

Domain: Financial Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r5/02-financial/)

**Editorial question:** What operating-income capacity disappears before credit losses accelerate?

**Evidence:** Finanstilsynet, Finanstilsynet.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
