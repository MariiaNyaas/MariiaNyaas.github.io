# Methodology — The Model-Risk Boundary of Supervisory Stress

## Hypothesis and data
How sensitive is a scenario loss proxy to model overlays?

- **Norwegian stress bank loan losses / assets:** 1.59 % assets, period 2028 stress. Finanstilsynet. [Original release](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/).
- **Norwegian stressed NII / total assets, minimum:** 1.52 % assets, period 2028 stress. Finanstilsynet. [Original release](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/).

## Reproducible scenario
Inputs: Illustrative exposed assets (NOK bn), Incremental model overlay (pp). Equation: exposed assets × scenario loss-rate overlay. Output unit: NOK bn. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
The overlay is not derived from borrower microdata. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
