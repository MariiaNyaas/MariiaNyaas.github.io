# The Model-Risk Boundary of Supervisory Stress

Stressed loan losses of 1.59% of assets should not be used as institution PDs.

Domain: Risk & Governance Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r5/04-governance/)

**Editorial question:** How sensitive is a scenario loss proxy to model overlays?

**Evidence:** Finanstilsynet, Finanstilsynet.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
