# Executive brief | The Model-Risk Boundary of Supervisory Stress

**Signal.** Stressed loan losses of 1.59% of assets should not be used as institution PDs.

**Decision question.** How sensitive is a scenario loss proxy to model overlays?

**Why it matters.** The observed indicators create a specific, testable challenge for risk or finance leadership. They are not proof of a company-level outcome.

**Quantitative illustration.** At initial inputs (80 NOK bn; 0.5 pp), the output is 0.400 NOK bn. This is entirely scenario-derived and not an observed amount.

**Management response.** Set model risk appetite, override logging and challenger scenario governance.

**Challenge.** The overlay is not derived from borrower microdata.

**Evidence:** [Finanstilsynet](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/) · [Finanstilsynet](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/)
