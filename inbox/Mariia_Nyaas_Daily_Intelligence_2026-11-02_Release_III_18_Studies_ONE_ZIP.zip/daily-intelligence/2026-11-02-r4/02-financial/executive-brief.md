# Executive brief | The Deposit-Mix Trap for Nordic Treasury

**Signal.** Household deposits increased 6%, corporate deposits 3%; equal volumes hide divergent stability.

**Decision question.** How quickly can a deposit-mix sensitivity change the funding-gap proxy?

**Why it matters.** The observed indicators create a specific, testable challenge for risk or finance leadership. They are not proof of a company-level outcome.

**Quantitative illustration.** At initial inputs (30 NOK bn; 12 %), the output is 3.600 NOK bn. This is entirely scenario-derived and not an observed amount.

**Management response.** Separate retail and corporate runoff assumptions in ALM contingency plans.

**Challenge.** Observed annual deposit growth is not a forecast of runoff in a crisis.

**Evidence:** [Finanstilsynet](https://www.finanstilsynet.no/publikasjoner-og-analyser/soliditetsrapporter-for-finansforetak/2026/html/likviditetssituasjonen-i-norske-banker/) · [Finanstilsynet](https://www.finanstilsynet.no/publikasjoner-og-analyser/soliditetsrapporter-for-finansforetak/2026/html/likviditetssituasjonen-i-norske-banker/)
