# The Deposit-Mix Trap for Nordic Treasury

Household deposits increased 6%, corporate deposits 3%; equal volumes hide divergent stability.

Domain: Financial Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r4/02-financial/)

**Editorial question:** How quickly can a deposit-mix sensitivity change the funding-gap proxy?

**Evidence:** Finanstilsynet, Finanstilsynet.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
