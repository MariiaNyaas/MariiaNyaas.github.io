# Methodology — Audit the Growth Narrative: GDP Level vs Pace

## Hypothesis and data
How sensitive are budget variances to small growth-impulse changes?

- **Euro area GDP growth Q2:** 0.6 % QoQ, period 2026-Q2. Eurostat. [Original release](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap).
- **Euro area GDP growth Q3:** 0.4 % QoQ, period 2026-Q3. Eurostat. [Original release](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap).

## Reproducible scenario
Inputs: Illustrative revenue budget (EUR m), GDP-growth pass-through sensitivity (x). Equation: Q2-Q3 EA GDP deceleration (0.2pp) × sensitivity × revenue. Output unit: same monetary unit as revenue. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
Top-down GDP is not a company-specific sales growth predictor. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
