# Methodology — Cyber Downtime as a Liquidity Event

## Hypothesis and data
What notional payment-processing volume is exposed during an ICT outage?

- **Norway policy rate:** 4.5 %, period 2026-09-24. Norges Bank. [Original release](https://www.norges-bank.no/en/topics/monetary-policy/policy-rate).
- **Norwegian stressed NII / total assets, minimum:** 1.52 % assets, period 2028 stress. Finanstilsynet. [Original release](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/).

## Reproducible scenario
Inputs: Illustrative daily payment flow (NOK bn), System downtime (hours). Equation: daily flow × capped outage duration / 24. Output unit: NOK bn. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
Payment disruption notional is not a loss or a forecast of settlement failure. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
