# Executive brief | Cyber Downtime as a Liquidity Event

**Signal.** Finanstilsynet warns cyber incidents can have systemic consequences.

**Decision question.** What notional payment-processing volume is exposed during an ICT outage?

**Why it matters.** The observed indicators create a specific, testable challenge for risk or finance leadership. They are not proof of a company-level outcome.

**Quantitative illustration.** At initial inputs (12 NOK bn; 5 hours), the output is 2.500 NOK bn. This is entirely scenario-derived and not an observed amount.

**Management response.** Connect DORA incident severity metrics to treasury intraday liquidity playbooks.

**Challenge.** Payment disruption notional is not a loss or a forecast of settlement failure.

**Evidence:** [Norges Bank](https://www.norges-bank.no/en/topics/monetary-policy/policy-rate) · [Finanstilsynet](https://www.finanstilsynet.no/en/publications/risk-outlook-reports/risk-outlook---june-2026/html/risk-outlook--june-2026/)
