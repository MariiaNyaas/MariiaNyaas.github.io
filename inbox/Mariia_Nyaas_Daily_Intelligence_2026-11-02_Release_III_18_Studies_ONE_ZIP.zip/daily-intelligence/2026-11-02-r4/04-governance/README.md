# Cyber Downtime as a Liquidity Event

Finanstilsynet warns cyber incidents can have systemic consequences.

Domain: Risk & Governance Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r4/04-governance/)

**Editorial question:** What notional payment-processing volume is exposed during an ICT outage?

**Evidence:** Norges Bank, Finanstilsynet.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
