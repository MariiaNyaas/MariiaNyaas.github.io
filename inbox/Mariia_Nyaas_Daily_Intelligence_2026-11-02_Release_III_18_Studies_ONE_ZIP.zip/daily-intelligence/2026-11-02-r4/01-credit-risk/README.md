# The Rate-Cut Mirage in Mortgage Underwriting

A 4.5% Norwegian policy rate leaves material transmission uncertainty before the next rate decision.

Domain: Credit Risk Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r4/01-credit-risk/)

**Editorial question:** How much incremental annual interest appears under small upward shocks?

**Evidence:** Norges Bank, Statistics Norway.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
