# Executive brief | The Rate-Cut Mirage in Mortgage Underwriting

**Signal.** A 4.5% Norwegian policy rate leaves material transmission uncertainty before the next rate decision.

**Decision question.** How much incremental annual interest appears under small upward shocks?

**Why it matters.** The observed indicators create a specific, testable challenge for risk or finance leadership. They are not proof of a company-level outcome.

**Quantitative illustration.** At initial inputs (3400000 NOK; 1 pp), the output is 34,000.000 input currency units/year. This is entirely scenario-derived and not an observed amount.

**Management response.** Stress borrower serviceability before assuming future rate relief.

**Challenge.** Simple interest approximation excludes amortisation and rate-pass-through timing.

**Evidence:** [Norges Bank](https://www.norges-bank.no/en/topics/monetary-policy/policy-rate) · [Statistics Norway](https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/)
