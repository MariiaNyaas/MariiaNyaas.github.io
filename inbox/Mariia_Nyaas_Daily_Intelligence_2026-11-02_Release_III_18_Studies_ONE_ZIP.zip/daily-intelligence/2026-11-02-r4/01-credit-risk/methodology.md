# Methodology — The Rate-Cut Mirage in Mortgage Underwriting

## Hypothesis and data
How much incremental annual interest appears under small upward shocks?

- **Norway policy rate:** 4.5 %, period 2026-09-24. Norges Bank. [Original release](https://www.norges-bank.no/en/topics/monetary-policy/policy-rate).
- **Norway CPI-ATE inflation:** 3.0 % YoY, period 2026-09. Statistics Norway. [Original release](https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/).

## Reproducible scenario
Inputs: Illustrative floating-rate balance (NOK), Additional repricing (pp). Equation: simple exposure × rate. Output unit: input currency units/year. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
Simple interest approximation excludes amortisation and rate-pass-through timing. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
