# Executive brief | The Norwegian Services Inflation Wedge

**Signal.** Services inflation of 3.8% exceeds underlying CPI-ATE of 3.0%.

**Decision question.** How much margin could be absorbed by wage-and-service procurement inflation?

**Why it matters.** The observed indicators create a specific, testable challenge for risk or finance leadership. They are not proof of a company-level outcome.

**Quantitative illustration.** At initial inputs (90 NOK m; 1.5 pp), the output is 1.350 same monetary unit as exposure. This is entirely scenario-derived and not an observed amount.

**Management response.** Separate services cost escalation from headline planning assumptions.

**Challenge.** CPI-ATE and services CPI differ in basket composition and methodology.

**Evidence:** [Statistics Norway](https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/) · [Statistics Norway](https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/)
