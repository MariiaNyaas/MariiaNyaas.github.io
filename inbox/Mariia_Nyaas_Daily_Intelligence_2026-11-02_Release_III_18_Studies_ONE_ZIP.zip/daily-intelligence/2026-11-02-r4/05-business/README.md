# The Norwegian Services Inflation Wedge

Services inflation of 3.8% exceeds underlying CPI-ATE of 3.0%.

Domain: Business & Economic Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r4/05-business/)

**Editorial question:** How much margin could be absorbed by wage-and-service procurement inflation?

**Evidence:** Statistics Norway, Statistics Norway.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
