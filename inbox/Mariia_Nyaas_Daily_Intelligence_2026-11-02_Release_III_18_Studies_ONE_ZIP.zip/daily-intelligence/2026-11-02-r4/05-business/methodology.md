# Methodology — The Norwegian Services Inflation Wedge

## Hypothesis and data
How much margin could be absorbed by wage-and-service procurement inflation?

- **Norway services inflation:** 3.8 % YoY, period 2026-09. Statistics Norway. [Original release](https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/).
- **Norway CPI-ATE inflation:** 3.0 % YoY, period 2026-09. Statistics Norway. [Original release](https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/).

## Reproducible scenario
Inputs: Illustrative annual services procurement (NOK m), Extra cost inflation above core (pp). Equation: expense base × assumed escalation. Output unit: same monetary unit as exposure. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
CPI-ATE and services CPI differ in basket composition and methodology. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
