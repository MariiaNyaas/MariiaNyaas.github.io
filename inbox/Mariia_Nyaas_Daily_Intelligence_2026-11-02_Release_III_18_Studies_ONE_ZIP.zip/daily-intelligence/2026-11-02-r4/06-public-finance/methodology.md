# Methodology — The EU–Euro Area Debt Gap Is Not a Credit Spread

## Hypothesis and data
How big is a scenario servicing bill for a hypothetical sovereign debt stock?

- **Euro area government debt:** 88.8 % GDP, period 2026-Q2. Eurostat. [Original release](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-bp).
- **EU government debt:** 82.9 % GDP, period 2026-Q2. Eurostat. [Original release](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-bp).

## Reproducible scenario
Inputs: Illustrative government debt (EUR bn), Average refinancing rate shock (pp). Equation: simple exposure × rate. Output unit: input currency units/year. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
Different member-state groupings explain composition; the ratio gap does not identify risk premium. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
