# The EU–Euro Area Debt Gap Is Not a Credit Spread

Euro-area government debt (88.8% GDP) exceeds EU debt (82.9% GDP).

Domain: Public Finance Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r4/06-public-finance/)

**Editorial question:** How big is a scenario servicing bill for a hypothetical sovereign debt stock?

**Evidence:** Eurostat, Eurostat.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
