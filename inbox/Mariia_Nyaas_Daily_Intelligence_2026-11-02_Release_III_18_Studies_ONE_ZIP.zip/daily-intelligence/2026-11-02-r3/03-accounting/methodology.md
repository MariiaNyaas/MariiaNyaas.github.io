# Methodology — Insurance Inflation and Audit Materiality Creep

## Hypothesis and data
How large could expense estimation error be under different materiality thresholds?

- **Norway insurance and finance services inflation:** 7.9 % YoY, period 2026-09. Statistics Norway. [Original release](https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/).
- **Norway headline inflation:** 3.4 % YoY, period 2026-09. Statistics Norway. [Original release](https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/).

## Reproducible scenario
Inputs: Illustrative contract spend (NOK m), Uncaptured price escalation (%). Equation: expense base × assumed escalation. Output unit: same monetary unit as exposure. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
The stressed escalation is illustrative; observed CPI is not a company contract rate. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
