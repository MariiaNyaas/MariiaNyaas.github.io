# Norway–ECB Rate Divergence and the FX Funding Gate

The 200 bp policy differential is not a hedgeable FX carry profit.

Domain: Financial Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r3/02-financial/)

**Editorial question:** What additional funding bill arises from a widening EUR/NOK funding spread?

**Evidence:** Norges Bank, European Central Bank.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
