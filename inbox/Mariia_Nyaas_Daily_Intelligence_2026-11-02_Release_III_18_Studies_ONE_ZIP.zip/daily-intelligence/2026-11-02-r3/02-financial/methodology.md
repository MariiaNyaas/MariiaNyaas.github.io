# Methodology — Norway–ECB Rate Divergence and the FX Funding Gate

## Hypothesis and data
What additional funding bill arises from a widening EUR/NOK funding spread?

- **Norway policy rate:** 4.5 %, period 2026-09-24. Norges Bank. [Original release](https://www.norges-bank.no/en/topics/monetary-policy/policy-rate).
- **ECB deposit facility rate:** 2.5 %, period 2026-10-29. European Central Bank. [Original release](https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html).

## Reproducible scenario
Inputs: Illustrative EUR wholesale funding (EUR bn), Extra funding spread (pp). Equation: simple exposure × rate. Output unit: input currency units/year. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
Policy-rate differentials omit basis swaps, collateral and bank-specific spreads. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
