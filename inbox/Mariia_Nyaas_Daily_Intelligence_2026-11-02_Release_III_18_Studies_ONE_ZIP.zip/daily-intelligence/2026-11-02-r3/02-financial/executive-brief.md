# Executive brief | Norway–ECB Rate Divergence and the FX Funding Gate

**Signal.** The 200 bp policy differential is not a hedgeable FX carry profit.

**Decision question.** What additional funding bill arises from a widening EUR/NOK funding spread?

**Why it matters.** The observed indicators create a specific, testable challenge for risk or finance leadership. They are not proof of a company-level outcome.

**Quantitative illustration.** At initial inputs (25 EUR bn; 0.75 pp), the output is 0.188 input currency units/year. This is entirely scenario-derived and not an observed amount.

**Management response.** Keep cross-currency basis and hedge costs separate from policy-rate comparisons.

**Challenge.** Policy-rate differentials omit basis swaps, collateral and bank-specific spreads.

**Evidence:** [Norges Bank](https://www.norges-bank.no/en/topics/monetary-policy/policy-rate) · [European Central Bank](https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html)
