# Methodology — The Silent Insurance-Cost Shock to Norwegian Affordability

## Hypothesis and data
What expenditure share turns a niche price surge into an affordability warning?

- **Norway insurance and finance services inflation:** 7.9 % YoY, period 2026-09. Statistics Norway. [Original release](https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/).
- **Norway headline inflation:** 3.4 % YoY, period 2026-09. Statistics Norway. [Original release](https://www.ssb.no/en/priser-og-prisindekser/konsumpriser/statistikk/konsumprisindeksen/).

## Reproducible scenario
Inputs: Insured spending per month (NOK), Incremental insurance inflation (%). Equation: expense escalation. Output unit: NOK/month. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
Expense category inflation is a consumption-price signal, not a measured default transition. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
