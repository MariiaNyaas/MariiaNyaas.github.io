# The Silent Insurance-Cost Shock to Norwegian Affordability

A 7.9% insurance/financial-services price rise may erode discretionary income faster than headline CPI suggests.

Domain: Credit Risk Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r3/01-credit-risk/)

**Editorial question:** What expenditure share turns a niche price surge into an affordability warning?

**Evidence:** Statistics Norway, Statistics Norway.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
