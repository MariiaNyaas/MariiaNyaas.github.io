# Concentration Behind Norwegian Covered-Bond Liquidity

The supervisor reports roughly half of banks above its 50% OMF liquidity reserve recommendation.

Domain: Risk & Governance Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r3/04-governance/)

**Editorial question:** How much HQLA buffer may become concentrated if the share is too high?

**Evidence:** Finanstilsynet, Finanstilsynet.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
