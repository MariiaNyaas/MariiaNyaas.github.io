# Executive brief | Concentration Behind Norwegian Covered-Bond Liquidity

**Signal.** The supervisor reports roughly half of banks above its 50% OMF liquidity reserve recommendation.

**Decision question.** How much HQLA buffer may become concentrated if the share is too high?

**Why it matters.** The observed indicators create a specific, testable challenge for risk or finance leadership. They are not proof of a company-level outcome.

**Quantitative illustration.** At initial inputs (45 NOK bn; 65 %), the output is 6.750 NOK bn. This is entirely scenario-derived and not an observed amount.

**Management response.** Track issuer, geography and collateral correlations in second-line review.

**Challenge.** Illustration tests a limit gap, not actual holdings of any institution.

**Evidence:** [Finanstilsynet](https://www.finanstilsynet.no/publikasjoner-og-analyser/soliditetsrapporter-for-finansforetak/2026/html/likviditetssituasjonen-i-norske-banker/) · [Finanstilsynet](https://www.finanstilsynet.no/publikasjoner-og-analyser/soliditetsrapporter-for-finansforetak/2026/html/likviditetssituasjonen-i-norske-banker/)
