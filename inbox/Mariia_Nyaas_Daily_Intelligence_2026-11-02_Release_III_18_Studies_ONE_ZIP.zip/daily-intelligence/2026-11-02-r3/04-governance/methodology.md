# Methodology — Concentration Behind Norwegian Covered-Bond Liquidity

## Hypothesis and data
How much HQLA buffer may become concentrated if the share is too high?

- **Household deposit annual growth:** 6 % YoY, period 2026-Q2. Finanstilsynet. [Original release](https://www.finanstilsynet.no/publikasjoner-og-analyser/soliditetsrapporter-for-finansforetak/2026/html/likviditetssituasjonen-i-norske-banker/).
- **Corporate deposit annual growth:** 3 % YoY, period 2026-Q2. Finanstilsynet. [Original release](https://www.finanstilsynet.no/publikasjoner-og-analyser/soliditetsrapporter-for-finansforetak/2026/html/likviditetssituasjonen-i-norske-banker/).

## Reproducible scenario
Inputs: Illustrative liquidity buffer (NOK bn), Covered-bond concentration (%). Equation: buffer × max(share – 50%,0). Output unit: NOK bn. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
Illustration tests a limit gap, not actual holdings of any institution. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
