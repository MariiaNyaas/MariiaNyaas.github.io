# GDP Growth without Momentum: The European Export Check

Euro area growth slowed from 0.6% to 0.4% QoQ even as growth remains positive.

Domain: Business & Economic Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r3/05-business/)

**Editorial question:** How much Nordic exporter revenue is at risk under an assumed growth elasticity?

**Evidence:** Eurostat, Eurostat.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
