# The Debt-Stock Drift Masked by Positive GDP

Euro-area debt rose from 88.4% to 88.8% of GDP in Q2.

Domain: Public Finance Intelligence. Date: 2026-11-02.

[Open published dashboard](https://mariianyaas.github.io/daily-intelligence/2026-11-02-r3/06-public-finance/)

**Editorial question:** What nominal-debt pressure follows from financing-cost shocks?

**Evidence:** Eurostat, Eurostat.

The interactive calculation is an illustrative sensitivity, not a model validated on individual observations.
