# Methodology — The Debt-Stock Drift Masked by Positive GDP

## Hypothesis and data
What nominal-debt pressure follows from financing-cost shocks?

- **Euro area government debt Q1:** 88.4 % GDP, period 2026-Q1. Eurostat. [Original release](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-bp).
- **Euro area government debt:** 88.8 % GDP, period 2026-Q2. Eurostat. [Original release](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-21102026-bp).

## Reproducible scenario
Inputs: Illustrative public debt stock (EUR bn), Additional average debt funding cost (pp). Equation: simple exposure × rate. Output unit: input currency units/year. Calculated on every input change; the six chart points vary the second input between 0.25× and 1.5×.

## Identification and limitations
The Q1-Q2 GDP debt ratios are observed; illustrative debt stock is not a country figure. This is not a calibrated statistical model, causal estimate, predictive backtest or bank-specific recommendation. Public source observations may have different reporting periods. All scenario parameters are clearly illustrative.

## Validation path
Retrieve source series, test exposure-weighted distributions, examine lag structure and counterfactuals, and conduct out-of-sample evaluation before assigning forecasting value.
