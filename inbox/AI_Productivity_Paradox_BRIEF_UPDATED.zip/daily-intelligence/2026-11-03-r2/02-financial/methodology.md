# Methodology — The AI Productivity Paradox

**Edition:** 2026-11-03  
**Classification:** Independent exploratory research; descriptive analysis and explicitly hypothetical scenario modelling.

## Research question

Can investment and AI adoption indicators precede a measurable productivity response, and how sensitive is that apparent relationship to the chosen indicator, time window, transformation and lag?

This is motivated by public discussion of the AI investment cycle and concentration, but it is **not** a question attributed verbatim to Nicolai Tangen or a study commissioned by NBIM.

## Primary dataset

Federal Reserve Board, *The AI Buildout*, FEDS Notes, 17 July 2026, **figure-data XLSX**:
https://www.federalreserve.gov/econres/notes/feds-notes/feds-ai-buildout-figure-data.xlsx

The supplied workbook contains `Data_Sources` and `Figure_1` through `Figure_11`. The packaged `data.json` retains 11 figure worksheets with 627 observations/records across their native periods. `variables.json` documents 26 selectable indicators. The original XLSX should be retained for full provenance and independent reproducibility. Figure_1 and Figure_2 are event-level observations, preserved in the JSON but excluded from quarterly comparisons.

**Important:** The figure data do not contain stock prices, valuations, consensus earnings, risk premia or a direct measure of aggregate AI-attributable total-factor productivity. The dashboard therefore cannot establish whether the market has priced AI correctly.

## Extraction

- Original workbook rows 1–3 contain figure titles, units and spacing; row 4 contains column headings.
- Valid observation rows start at row 5. Source footers and other non-date rows are excluded.
- Dates are retained as ISO dates, YYYY-MM months or YYYY:Qn quarters.
- Numeric-looking cells, including text-formatted numerical values in Figure_7, are parsed as numbers.
- Missing values remain null. No forward fill, interpolation or estimation is applied.
- Figure_4 CAPEX is **nominal USD billions per quarter**, not pure AI spending.
- Figure_5 mixes monthly construction and quarterly equipment values; quarterly aggregation follows the rules below.
- Figure_9 provides quarterly productivity growth as a **four-quarter moving average**; this is not a productivity level.

## Time alignment and correlation

1. Each observation is assigned to its calendar quarter.
2. If a series contains multiple observations in a quarter, their arithmetic mean is used. This is a visual-alignment convenience; a monthly level or index averaged across a quarter is not equivalent to a quarterly flow or quarterly total.
3. Select two series, A and B. With lag L, pair A(t) with B(t+L).
4. Restrict to the selected calendar window and to available observations in both series.
5. Available transformations: native values, rebased indices to 100 at the first common non-zero pair, first differences, and quarter-on-quarter percentage changes.
6. First differences and percentage changes are only calculated for *consecutive* available quarters. Percentage changes are omitted if the previous value is zero.
7. Pearson correlation is displayed only for at least eight matched quarters with non-zero variance.

The correlation is descriptive. Serial correlation, smoothing in the source data, common trends, omitted variables, simultaneity and short samples can invalidate causal interpretations. Rebased level correlations are particularly vulnerable to spurious trend correlation. Comparing transformed series is a sensitivity check, not causal identification.

## Adoption and productivity panels

The adoption panel plots small (1–4 employees) and large (250+ employees) firms from Figure_8. Observations are not extrapolated beyond available survey dates.

The productivity panel compares high and low AI-exposure sector groups from Figure_9, which are four-quarter moving-average quarterly growth rates. Their difference does **not** identify an AI treatment effect; sector composition, business cycle, capital intensity and pre-existing trends are potential confounders.

## Hypothetical sensitivity laboratory

Ten analyst-defined sliders:

1. Business adoption rate (%)
2. Share of tasks influenced by AI (%)
3. Productivity gain on influenced tasks (%)
4. Benefit realisation factor (%)
5. Deployment delay (quarters)
6. Evaluation horizon (quarters)
7. Annual benefit erosion (%)
8. Initial investment burden (analyst-defined points)
9. Annual operating burden (analyst-defined points)
10. Annual discount rate (%)

The annual uplift is `adoption × task reach × task gain × realisation`, with all four inputs converted from percentages to fractions. This is a hypothetical arithmetic mapping, **not** an empirical estimate or calibration to the Federal Reserve data.

For quarters after the deployment delay, an assumed annual uplift is discounted by an annual erosion factor. Annual uplift and operating burden are divided by four to form a quarterly benefit-index flow. Each quarterly net flow is discounted at `(1 + annual_discount_rate)^(quarter/4)`. The initial investment burden is deducted once. The break-even adoption threshold uses linear scaling of gross benefits with adoption, holding all other assumptions fixed. When no benefit can be generated, break-even is undefined.

The scenario output is an **analyst-defined index**. It is not percentage-point GDP growth, firm earnings, net present value in currency, equity valuation or a probabilistic forecast. Its units should not be interpreted as an observed economic quantity.

## Limitations and governance

- AI-related and non-AI technology investment cannot be separated precisely from the CAPEX aggregates.
- The source figures cover different periods and frequencies; some series overlap for very few quarters.
- Figure_7 GDP growth contributions are in percentage points and must not be treated as investment shares.
- The dashboard does not identify a causal effect or validate either research hypothesis.
- No inference about Norges Bank Investment Management's holdings or investment decisions is made.
- Research findings should be interpreted with the published source methodology and figure footnotes.
- No confidential employer information is included.

## Reproduction

Open `index.html` in a modern browser. The source observations and variable dictionary are embedded in the HTML, so no network or external JavaScript library is required. `data.json` and `variables.json` are also provided separately for machine-readable reuse. Use the built-in export controls to download the currently aligned CSV and the complete extracted data.

The original XLSX is the authoritative source; if the source is revised, repeat extraction and document the revision date.

## Research Intelligence Brief — numerical audit (added 03 November 2026)

The editorial brief uses the workbook's **native figures**, not quarterly-aligned dashboard transformations:

1. **Figure 4, combined technology-firm CAPEX:** Sum Amazon, Google, Meta, Microsoft and Other. 2019 Q1 = 3.29+4.64+3.84+2.56+0.44 = **14.77** USD bn. 2025 Q1 = **79.18** USD bn. 2026 Q1 = 44.20+35.67+19.00+30.88+26.33 = **156.08** USD bn. Year-on-year growth = `(156.08 / 79.18 - 1) × 100 = 97.12%`, shown as 97.1%. Includes non-AI spending.
2. **Figure 8, firm-size adoption:** 2025-12-28, small (1–4) = 17.30%, large (250+) = 30.33%, gap 13.03 pp. 2026-06-14, small = 19.80%, large = 38.48%, gap 18.68 pp. Increase in gap = 5.65 pp. Source survey methodology governs interpretation.
3. **Figure 9, productivity:** 2026 Q1, high-exposure = 1.49%, low-exposure = 0.17%; high-minus-low = 1.32 percentage points. These are four-quarter moving-average quarterly productivity growth rates, not treatment effects.
4. **Figure 7, contributions to GDP growth:** 2026 Q1 computer-equipment investment = +0.59 pp; computer and peripheral net exports = −0.45 pp. Different national-accounts components; not an AI-only decomposition.
5. **Interpretive finding:** coexistence of CAPEX growth, uneven adoption and productivity divergence does not establish causality, market overvaluation or the winner between delayed diffusion and investment overshoot. The workbook contains no equity valuations or earnings expectations.

The decision matrix is **conditional**, not a summary of observed scenarios. Research claims are deliberately weaker than the investment framing where the data do not support causal or valuation conclusions.
