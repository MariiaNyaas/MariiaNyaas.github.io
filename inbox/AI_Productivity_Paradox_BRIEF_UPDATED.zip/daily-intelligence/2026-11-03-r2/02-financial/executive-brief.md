# Research Intelligence Brief — The AI Productivity Paradox

**Financial Intelligence · 03 November 2026**

## Central insight

**The investment surge is measurable. Its productivity dividend remains harder to isolate.**

## Five source-verified findings

1. **Technology CAPEX:** Five categories in Federal Reserve Figure 4 total **$156.08bn in 2026 Q1**, compared with **$79.18bn in 2025 Q1**, an increase of **97.1% year-on-year**. Not AI-only spending.
2. **Adoption inequality:** Large-firm (250+ employees) adoption reached **38.48%**, versus **19.80%** among firms with 1–4 employees, on 14 June 2026: an **18.68 percentage-point gap**, up from **13.03 pp** on 28 December 2025 (Figure 8).
3. **Productivity divergence:** High AI-exposure sector productivity growth was **1.49%** versus **0.17%** for low exposure in 2026 Q1, a **1.32 pp** difference in four-quarter moving-average growth rates (Figure 9). This does not identify AI's causal effect.
4. **GDP composition:** Computer-equipment investment contributed **+0.59 pp** to GDP growth in 2026 Q1, while net exports of computers and related parts contributed **−0.45 pp** (Figure 7). Not an AI ROI measure.
5. **The identification gap:** The data support the existence of an investment boom, uneven adoption and sectoral divergence; they do **not** determine whether equities are overvalued or whether the productivity payoff is merely delayed.

## Investor's Decision Matrix

| Conditional pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| CAPEX rises; adoption rises; productivity flat | Diffusion delay or overinvestment | Longer lags, controls, deployment costs |
| CAPEX slows; productivity accelerates | Possible realised payoff | Cross-industry persistence and cyclical adjustment |
| Large-firm adoption outpaces small-firm adoption | Unequal diffusion | Firm-level productivity and margins |
| Productivity improves; valuations expand faster | Potential valuation disconnect | Forward earnings, discount rates, valuation series |

## What would change our mind?

A persistent, sector-adjusted productivity response following AI adoption would strengthen delayed diffusion. Mature adoption with persistently weak measured returns would strengthen investment overshoot. Current figures cannot discriminate conclusively.

**Source:** Federal Reserve Board, *The AI Buildout*, FEDS Notes figure-data workbook, 17 July 2026. Full audit calculations and limitations are in `methodology.md`.
