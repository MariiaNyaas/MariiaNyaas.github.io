# The AI Productivity Paradox — GitHub publishing package

Research date: 2026-11-03.

## Files
- `index.html` — standalone interactive dashboard (source data embedded).
- `data.json` — extracted Federal Reserve source observations.
- `variables.json` — dictionary of 26 selectable series.
- `methodology.md` — data provenance, transformation and scenario assumptions.

## Publish
Create `daily-intelligence/2026-11-03/19-ai-productivity-paradox/` in your GitHub Pages repository and upload all four files there. The standalone dashboard works immediately at the matching GitHub Pages URL. It will **not automatically appear in the main portfolio index** unless your `research.json` or site-generation workflow is updated to register the new page.

## Important
This is an exploratory, non-causal analysis. It is not a valuation model or an empirically calibrated AI-productivity forecast.
