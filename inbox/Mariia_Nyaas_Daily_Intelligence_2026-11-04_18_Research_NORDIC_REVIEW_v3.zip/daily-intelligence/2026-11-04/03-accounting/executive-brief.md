# Research Intelligence Brief — Energy-driven inventory impairment watchlist

**Accounting & Audit Intelligence · 04 November 2026**

## Central insight
Higher energy inflation is an audit trigger for energy-intensive inventory carrying values, not evidence of an actual write-down.

## Five numerical observations / calculations
1. **Euro area energy contribution: 1.71 pp** (2026-09; [EU_HICP](https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap)).
2. **Euro area services contribution: 1.52 pp** (2026-09; [EU_HICP](https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap)).
3. **Euro area goods contribution: 0.29 pp** (2026-09; [EU_HICP](https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap)).
4. **Euro area food contribution: 0.25 pp** (2026-09; [EU_HICP](https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap)).
5. **Calculated: Euro area energy contribution minus Euro area services contribution: 0.19 pp**. 1.71 − 1.52 = 0.19. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Energy contributes materially to annual HICP | Separate denominator, exposure and timing effects. |
| Amplified shock | energy cost impulse and energy-intensive inventory share increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | Observed NRV headroom remaining ample would weaken impairment risk. |

## What Would Change Our Mind?
Observed NRV headroom remaining ample would weaken impairment risk.

## Practical implication
Prioritise NRV tests where production costs and selling prices diverge.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

A 0.23 percentage-point quarterly increase in the mortgage census rate may raise refinancing sensitivity, but entity-specific going-concern and impairment conclusions require contractual cash-flow evidence.

- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak
- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
