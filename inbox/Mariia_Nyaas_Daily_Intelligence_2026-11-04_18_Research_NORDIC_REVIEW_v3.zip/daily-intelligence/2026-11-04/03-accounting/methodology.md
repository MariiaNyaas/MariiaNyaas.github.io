# Methodology — Energy-driven inventory impairment watchlist

## Source and reference periods
- Euro area energy contribution: 1.71 pp, reference 2026-09, release 2026-10-16, https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap
- Euro area services contribution: 1.52 pp, reference 2026-09, release 2026-10-16, https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap
- Euro area goods contribution: 0.29 pp, reference 2026-09, release 2026-10-16, https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap
- Euro area food contribution: 0.25 pp, reference 2026-09, release 2026-10-16, https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap
- Headline HICP expectation, 2026: 3.0 %, reference 2026 forecast, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- Headline HICP expectation, 2027: 2.6 %, reference 2027 forecast, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html

## Derived calculation
1.71 − 1.52 = 0.19 (pp). Difference is descriptive; compare the underlying reference periods and definitions.

## Sensitivity calculation (hypothetical)
`index_points = shock_percent * exposure_percent / 100 * transmission_percent / 100`. This is an illustrative index per 100 reference units. It is NOT an estimated economic relationship. Default shock=3%, exposure=45%, transmission=75%; result=1.0125 index points. Controls: shock 0–10%; exposure 0–100%; transmission 0–200%.

## Research question and causal caution
Higher energy inflation is an audit trigger for energy-intensive inventory carrying values, not evidence of an actual write-down.
Mechanisms to investigate: Energy intensity; selling-price pass-through; stock turnover. Leading indicator: inventory NRV headroom.
Falsification: Observed NRV headroom remaining ample would weaken impairment risk.
No causal identification, time-series model, predictive power, equity valuation, backtest, entity-level accounting conclusion or country-specific transfer coefficient is established. Cross-horizon comparisons are contextual, not matched.

## Review caveats
Eurostat GDP Q3 is preliminary. ECB SPF Q4 2026 is a survey of 52 responses conducted 2–7 October and published 30 October; forecasts are expectations, not realised data. September HICP was published 16 October and is contextual (outside the seven-day release window). Norway-specific risk implications are proposed channels, not directly measured outcomes.


## Independent Norwegian contextual cross-check

A 0.23 percentage-point quarterly increase in the mortgage census rate may raise refinancing sensitivity, but entity-specific going-concern and impairment conclusions require contractual cash-flow evidence.

- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak
- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
