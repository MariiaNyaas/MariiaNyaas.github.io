# Research Intelligence Brief — Employment stock-rate divergence and PD overlay discipline

**Credit Risk Intelligence · 04 November 2026**

## Central insight
An unchanged month-on-month unemployment rate can coexist with a larger unemployed population, but cannot by itself establish a higher default probability.

## Five numerical observations / calculations
1. **Euro area unemployment rate: 6.5 %** (2026-09; [EU_LABOUR](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp)).
2. **Euro area unemployment rate year earlier: 6.3 %** (2025-09; [EU_LABOUR](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp)).
3. **Euro area unemployed persons: 11.555 million** (2026-09; [EU_LABOUR](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp)).
4. **Euro area unemployed annual change: 420 thousand** (2026-09 vs 2025-09; [EU_LABOUR](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp)).
5. **Calculated: Euro area unemployment rate minus Euro area unemployment rate year earlier: 0.2 pp**. 6.5 − 6.3 = 0.2. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Rising unemployed headcount while the monthly rate stays stable | Separate denominator, exposure and timing effects. |
| Amplified shock | unemployment pipeline and borrower exposure share increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | Stable employment headcount and arrears would weaken a pipeline-stress hypothesis. |

## What Would Change Our Mind?
Stable employment headcount and arrears would weaken a pipeline-stress hypothesis.

## Practical implication
Credit officers should reconcile headcount, rate, sector and lag before recalibrating PD overlays.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

Household credit growth slowed to 4.5% y/y while corporate credit growth reached 5.9%; portfolio-wide PD overlays should distinguish borrower segments and verify arrears rather than infer a single stress direction.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
