# Methodology — Employment stock-rate divergence and PD overlay discipline

## Source and reference periods
- Euro area unemployment rate: 6.5 %, reference 2026-09, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp
- Euro area unemployment rate year earlier: 6.3 %, reference 2025-09, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp
- Euro area unemployed persons: 11.555 million, reference 2026-09, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp
- Euro area unemployed annual change: 420 thousand, reference 2026-09 vs 2025-09, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp
- Headline HICP expectation, 2026: 3.0 %, reference 2026 forecast, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- Headline HICP expectation, 2027: 2.6 %, reference 2027 forecast, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html

## Derived calculation
6.5 − 6.3 = 0.2 (pp). Difference is descriptive; compare the underlying reference periods and definitions.

## Sensitivity calculation (hypothetical)
`index_points = shock_percent * exposure_percent / 100 * transmission_percent / 100`. This is an illustrative index per 100 reference units. It is NOT an estimated economic relationship. Default shock=3%, exposure=45%, transmission=75%; result=1.0125 index points. Controls: shock 0–10%; exposure 0–100%; transmission 0–200%.

## Research question and causal caution
A flat unemployment rate can hide a larger absolute distressed population, but cannot by itself establish a higher default probability.
Mechanisms to investigate: Workforce denominator change; sector exposure; lagged delinquency. Leading indicator: monthly delinquency and unemployment headcount.
Falsification: Stable employment headcount and arrears would weaken a pipeline-stress hypothesis.
No causal identification, time-series model, predictive power, equity valuation, backtest, entity-level accounting conclusion or country-specific transfer coefficient is established. Cross-horizon comparisons are contextual, not matched.

## Review caveats
Eurostat GDP Q3 is preliminary. ECB SPF Q4 2026 is a survey of 52 responses conducted 2–7 October and published 30 October; forecasts are expectations, not realised data. September HICP was published 16 October and is contextual (outside the seven-day release window). Norway-specific risk implications are proposed channels, not directly measured outcomes.


## Independent Norwegian contextual cross-check

Household credit growth slowed to 4.5% y/y while corporate credit growth reached 5.9%; portfolio-wide PD overlays should distinguish borrower segments and verify arrears rather than infer a single stress direction.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
