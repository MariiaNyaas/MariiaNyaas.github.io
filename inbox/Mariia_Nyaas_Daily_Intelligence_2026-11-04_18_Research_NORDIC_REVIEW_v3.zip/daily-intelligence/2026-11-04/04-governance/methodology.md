# Methodology — Energy pass-through as a second-order risk governance test

## Source and reference periods
- Euro area energy contribution: 1.71 pp, reference 2026-09, release 2026-10-16, https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap
- Euro area services contribution: 1.52 pp, reference 2026-09, release 2026-10-16, https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap
- Euro area goods contribution: 0.29 pp, reference 2026-09, release 2026-10-16, https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap
- Euro area food contribution: 0.25 pp, reference 2026-09, release 2026-10-16, https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap
- Headline HICP expectation, 2026: 3.0 %, reference 2026 forecast, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- Headline HICP expectation, 2027: 2.6 %, reference 2027 forecast, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html

## Derived calculation
1.71 − 1.52 = 0.19 (pp). Difference is descriptive; compare the underlying reference periods and definitions.

## Sensitivity calculation (hypothetical)
`index_points = shock_percent * exposure_percent / 100 * transmission_percent / 100`. This is an illustrative index per 100 reference units. It is NOT an estimated economic relationship. Default shock=3%, exposure=45%, transmission=75%; result=1.0125 index points. Controls: shock 0–10%; exposure 0–100%; transmission 0–200%.

## Research question and causal caution
Energy can transmit through suppliers and wage bargaining with a lag; observed contribution shares are not causal coefficients.
Mechanisms to investigate: Supplier contracts; wage bargaining; pricing power. Leading indicator: core inflation and wage settlements.
Falsification: Falling core inflation despite energy pressure would weaken second-round concerns.
No causal identification, time-series model, predictive power, equity valuation, backtest, entity-level accounting conclusion or country-specific transfer coefficient is established. Cross-horizon comparisons are contextual, not matched.

## Review caveats
Eurostat GDP Q3 is preliminary. ECB SPF Q4 2026 is a survey of 52 responses conducted 2–7 October and published 30 October; forecasts are expectations, not realised data. September HICP was published 16 October and is contextual (outside the seven-day release window). Norway-specific risk implications are proposed channels, not directly measured outcomes.


## Independent Norwegian contextual cross-check

Domestic credit stock totals do not establish portfolio concentrations; the difference between corporate and household credit growth is a governance prompt for segment-specific stress limits.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
