# Research Intelligence Brief — Energy pass-through as a second-order risk governance test

**Risk & Governance Intelligence · 04 November 2026**

## Central insight
Energy can transmit through suppliers and wage bargaining with a lag; observed contribution shares are not causal coefficients.

## Five numerical observations / calculations
1. **Euro area energy contribution: 1.71 pp** (2026-09; [EU_HICP](https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap)).
2. **Euro area services contribution: 1.52 pp** (2026-09; [EU_HICP](https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap)).
3. **Euro area goods contribution: 0.29 pp** (2026-09; [EU_HICP](https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap)).
4. **Euro area food contribution: 0.25 pp** (2026-09; [EU_HICP](https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap)).
5. **Calculated: Euro area energy contribution minus Euro area services contribution: 0.19 pp**. 1.71 − 1.52 = 0.19. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Energy and services contributions coexist | Separate denominator, exposure and timing effects. |
| Amplified shock | energy shock and supplier concentration increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | Falling core inflation despite energy pressure would weaken second-round concerns. |

## What Would Change Our Mind?
Falling core inflation despite energy pressure would weaken second-round concerns.

## Practical implication
Require separate first-round, second-round and feedback-loop scenarios in risk appetite.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

Domestic credit stock totals do not establish portfolio concentrations; the difference between corporate and household credit growth is a governance prompt for segment-specific stress limits.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
