# Methodology — The positive-GDP / weakening-momentum paradox

## Source and reference periods
- Euro area GDP, Q3 quarter-on-quarter: 0.4 % q/q, reference 2026 Q3 flash, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- Euro area GDP, Q2 quarter-on-quarter: 0.6 % q/q, reference 2026 Q2, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- EU GDP, Q3 quarter-on-quarter: 0.5 % q/q, reference 2026 Q3 flash, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- EU GDP, Q2 quarter-on-quarter: 0.7 % q/q, reference 2026 Q2, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- Euro area unemployment rate: 6.5 %, reference 2026-09, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp
- EU unemployment rate: 6.2 %, reference 2026-09, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp

## Derived calculation
0.4 − 0.6 = -0.2 (pp). Difference is descriptive; compare the underlying reference periods and definitions.

## Sensitivity calculation (hypothetical)
`index_points = shock_percent * exposure_percent / 100 * transmission_percent / 100`. This is an illustrative index per 100 reference units. It is NOT an estimated economic relationship. Default shock=3%, exposure=45%, transmission=75%; result=1.0125 index points. Controls: shock 0–10%; exposure 0–100%; transmission 0–200%.

## Research question and causal caution
The euro area grew in Q3, yet quarterly momentum slowed; the distinction matters for staffing and inventory decisions.
Mechanisms to investigate: Orders; employment; working capital. Leading indicator: new orders and q/q GDP.
Falsification: Q4 orders and GDP accelerating would weaken the slowdown hypothesis.
No causal identification, time-series model, predictive power, equity valuation, backtest, entity-level accounting conclusion or country-specific transfer coefficient is established. Cross-horizon comparisons are contextual, not matched.

## Review caveats
Eurostat GDP Q3 is preliminary. ECB SPF Q4 2026 is a survey of 52 responses conducted 2–7 October and published 30 October; forecasts are expectations, not realised data. September HICP was published 16 October and is contextual (outside the seven-day release window). Norway-specific risk implications are proposed channels, not directly measured outcomes.


## Independent Norwegian contextual cross-check

Corporate domestic credit growth at 5.9% y/y versus household growth of 4.5% may reflect differing funding needs; distinguishing investment finance from working-capital pressure requires company and sector data.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
