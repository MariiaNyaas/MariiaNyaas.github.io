# Research Intelligence Brief — The positive-GDP / weakening-momentum paradox

**Business & Economic Intelligence · 04 November 2026**

## Central insight
The euro area grew in Q3, yet quarterly momentum slowed; the distinction matters for staffing and inventory decisions.

## Five numerical observations / calculations
1. **Euro area GDP, Q3 quarter-on-quarter: 0.4 % q/q** (2026 Q3 flash; [EU_GDP](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap)).
2. **Euro area GDP, Q2 quarter-on-quarter: 0.6 % q/q** (2026 Q2; [EU_GDP](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap)).
3. **EU GDP, Q3 quarter-on-quarter: 0.5 % q/q** (2026 Q3 flash; [EU_GDP](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap)).
4. **EU GDP, Q2 quarter-on-quarter: 0.7 % q/q** (2026 Q2; [EU_GDP](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap)).
5. **Calculated: Euro area GDP, Q3 quarter-on-quarter minus Euro area GDP, Q2 quarter-on-quarter: -0.2 pp**. 0.4 − 0.6 = -0.2. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Positive GDP but lower q/q growth | Separate denominator, exposure and timing effects. |
| Amplified shock | GDP momentum shock and cyclical sales share increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | Q4 orders and GDP accelerating would weaken the slowdown hypothesis. |

## What Would Change Our Mind?
Q4 orders and GDP accelerating would weaken the slowdown hypothesis.

## Practical implication
Use both level and acceleration measures in rolling forecasts.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

Corporate domestic credit growth at 5.9% y/y versus household growth of 4.5% may reflect differing funding needs; distinguishing investment finance from working-capital pressure requires company and sector data.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
