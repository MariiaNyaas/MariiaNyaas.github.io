# Methodology — The policy-path split inside ECB forecaster expectations

## Source and reference periods
- Deposit-rate 2.50% share: 48.0 % of respondents, reference 2026 Q4 modal expectations, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- Deposit-rate 2.75% share: 43.0 % of respondents, reference 2026 Q4 modal expectations, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- Headline HICP expectation, 2026: 3.0 %, reference 2026 forecast, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- Headline HICP expectation, 2027: 2.6 %, reference 2027 forecast, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- Deposit facility rate: 2.5 %, reference 2026-10-29 decision, release 2026-10-29, https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html
- Main refinancing rate: 2.65 %, reference 2026-10-29 decision, release 2026-10-29, https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html

## Derived calculation
48.0 − 43.0 = 5.0 (pp). Difference is descriptive; compare the underlying reference periods and definitions.

## Sensitivity calculation (hypothetical)
`index_points = shock_percent * exposure_percent / 100 * transmission_percent / 100`. This is an illustrative index per 100 reference units. It is NOT an estimated economic relationship. Default shock=3%, exposure=45%, transmission=75%; result=1.0125 index points. Controls: shock 0–10%; exposure 0–100%; transmission 0–200%.

## Research question and causal caution
A near-even split between 2.50% and 2.75% expectations signals material funding-path disagreement, not a probability-weighted ECB forecast.
Mechanisms to investigate: Rate pass-through; duration; funding mix. Leading indicator: SPF rate dispersion and funding spreads.
Falsification: A rapid collapse in dispersion would weaken the policy-uncertainty thesis.
No causal identification, time-series model, predictive power, equity valuation, backtest, entity-level accounting conclusion or country-specific transfer coefficient is established. Cross-horizon comparisons are contextual, not matched.

## Review caveats
Eurostat GDP Q3 is preliminary. ECB SPF Q4 2026 is a survey of 52 responses conducted 2–7 October and published 30 October; forecasts are expectations, not realised data. September HICP was published 16 October and is contextual (outside the seven-day release window). Norway-specific risk implications are proposed channels, not directly measured outcomes.


## Independent Norwegian contextual cross-check

The 5.35% quarterly mortgage rate and 4.50% policy rate describe different instruments and reference dates; their 0.85 percentage-point difference is a descriptive wedge, not a measured bank margin.

- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
