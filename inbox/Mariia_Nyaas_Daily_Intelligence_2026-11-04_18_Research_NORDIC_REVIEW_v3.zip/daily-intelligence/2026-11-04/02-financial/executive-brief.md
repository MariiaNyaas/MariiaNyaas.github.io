# Research Intelligence Brief — The policy-path split inside ECB forecaster expectations

**Financial Intelligence · 04 November 2026**

## Central insight
A near-even split between 2.50% and 2.75% expectations signals material funding-path disagreement, not a probability-weighted ECB forecast.

## Five numerical observations / calculations
1. **Deposit-rate 2.50% share: 48 % of respondents** (2026 Q4 modal expectations; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
2. **Deposit-rate 2.75% share: 43 % of respondents** (2026 Q4 modal expectations; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
3. **Headline HICP expectation, 2026: 3 %** (2026 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
4. **Headline HICP expectation, 2027: 2.6 %** (2027 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
5. **Calculated: Deposit-rate 2.50% share minus Deposit-rate 2.75% share: 5 pp**. 48.0 − 43.0 = 5.0. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Two competing deposit-rate modal expectations | Separate denominator, exposure and timing effects. |
| Amplified shock | rate uncertainty and floating-rate funding share increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | A rapid collapse in dispersion would weaken the policy-uncertainty thesis. |

## What Would Change Our Mind?
A rapid collapse in dispersion would weaken the policy-uncertainty thesis.

## Practical implication
Use a rate-distribution rather than a single policy-rate path in ALM decisions.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

The 5.35% quarterly mortgage rate and 4.50% policy rate describe different instruments and reference dates; their 0.85 percentage-point difference is a descriptive wedge, not a measured bank margin.

- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
