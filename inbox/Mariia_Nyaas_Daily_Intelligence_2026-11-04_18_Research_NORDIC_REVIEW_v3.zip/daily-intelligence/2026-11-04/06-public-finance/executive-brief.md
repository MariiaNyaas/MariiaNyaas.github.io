# Research Intelligence Brief — Inflation-linked revenue illusion versus real spending capacity

**Public Finance Intelligence · 04 November 2026**

## Central insight
Nominal tax bases can grow with inflation even when real fiscal room contracts; this is a hypothesis requiring national budget data.

## Five numerical observations / calculations
1. **Headline HICP expectation, 2026: 3 %** (2026 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
2. **Headline HICP expectation, 2027: 2.6 %** (2027 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
3. **Headline HICP expectation, 2028: 2 %** (2028 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
4. **Headline HICP revision, 2026: 0.3 pp** (Q4 versus Q3 SPF; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
5. **Calculated: Headline HICP expectation, 2026 minus Headline HICP expectation, 2027: 0.4 pp**. 3.0 − 2.6 = 0.4. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Inflation expected above target in 2027 | Separate denominator, exposure and timing effects. |
| Amplified shock | inflation surprise and indexed spending share increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | Tax collections outpacing indexed costs in real terms would weaken the squeeze. |

## What Would Change Our Mind?
Tax collections outpacing indexed costs in real terms would weaken the squeeze.

## Practical implication
Disaggregate inflation-linked revenue from indexed expenditure before declaring fiscal improvement.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

Municipal domestic debt grew 4.4% y/y on a NOK 839 billion stock; rate-sensitivity depends on refinancing structure and budgets, not a mechanically applied policy-rate shock.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
