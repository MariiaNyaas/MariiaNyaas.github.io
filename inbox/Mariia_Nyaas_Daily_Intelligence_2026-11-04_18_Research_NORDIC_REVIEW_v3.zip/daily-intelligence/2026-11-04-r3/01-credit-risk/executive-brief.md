# Research Intelligence Brief — Real-income squeeze despite anchored long-run inflation

**Credit Risk Intelligence · 04 November 2026**

## Central insight
A persistent near-term inflation premium can erode debt-service capacity even if long-run expectations remain anchored.

## Five numerical observations / calculations
1. **Wage growth expectation, 2026: 3.3 %** (2026 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
2. **Headline HICP expectation, 2026: 3 %** (2026 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
3. **Wage growth expectation, 2027: 3.1 %** (2027 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
4. **Headline HICP expectation, 2027: 2.6 %** (2027 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
5. **Calculated: Wage growth expectation, 2026 minus Headline HICP expectation, 2026: 0.3 pp**. 3.3 − 3.0 = 0.3. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Expected 2027 inflation above 2028 while wage growth slows | Separate denominator, exposure and timing effects. |
| Amplified shock | real income squeeze and exposed household share increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | Real wages recovering and payment performance stable would weaken the squeeze. |

## What Would Change Our Mind?
Real wages recovering and payment performance stable would weaken the squeeze.

## Practical implication
Stress real disposable income and affordability separately from headline nominal wage growth.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

Household credit growth slowed to 4.5% y/y while corporate credit growth reached 5.9%; portfolio-wide PD overlays should distinguish borrower segments and verify arrears rather than infer a single stress direction.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
