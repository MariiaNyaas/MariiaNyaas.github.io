# Research Intelligence Brief — The euro-area growth deceleration hidden by positive GDP

**Financial Intelligence · 04 November 2026**

## Central insight
Positive quarterly GDP growth can conceal a deterioration in momentum even as year-on-year comparisons improve.

## Five numerical observations / calculations
1. **Euro area GDP, Q3 quarter-on-quarter: 0.4 % q/q** (2026 Q3 flash; [EU_GDP](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap)).
2. **Euro area GDP, Q2 quarter-on-quarter: 0.6 % q/q** (2026 Q2; [EU_GDP](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap)).
3. **EU GDP, Q3 quarter-on-quarter: 0.5 % q/q** (2026 Q3 flash; [EU_GDP](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap)).
4. **EU GDP, Q2 quarter-on-quarter: 0.7 % q/q** (2026 Q2; [EU_GDP](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap)).
5. **Calculated: Euro area GDP, Q3 quarter-on-quarter minus Euro area GDP, Q2 quarter-on-quarter: -0.2 pp**. 0.4 − 0.6 = -0.2. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Q3 growth positive but lower than Q2 | Separate denominator, exposure and timing effects. |
| Amplified shock | growth slowdown and cyclical allocation share increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | A Q4 re-acceleration would invalidate a persistent-slowdown extrapolation. |

## What Would Change Our Mind?
A Q4 re-acceleration would invalidate a persistent-slowdown extrapolation.

## Practical implication
Use quarter-on-quarter acceleration alongside annual growth in tactical allocation.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

The 5.35% quarterly mortgage rate and 4.50% policy rate describe different instruments and reference dates; their 0.85 percentage-point difference is a descriptive wedge, not a measured bank margin.

- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
