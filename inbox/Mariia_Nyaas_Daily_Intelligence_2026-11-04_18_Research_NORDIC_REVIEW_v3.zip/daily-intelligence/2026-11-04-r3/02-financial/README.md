# The euro-area growth deceleration hidden by positive GDP

Standalone GitHub Pages project, published under `daily-intelligence/2026-11-04-r3/02-financial/`.

Open `index.html`; data are embedded as displayed native official figures and separately recorded in `data.json`. Three scenario controls are explicitly hypothetical. The Research Intelligence Brief is synchronized with `executive-brief.md` and `methodology.md`.

Source observations were transcribed from the linked official releases. Publication is subject to human review.


## Norwegian evidence

The 5.35% quarterly mortgage rate and 4.50% policy rate describe different instruments and reference dates; their 0.85 percentage-point difference is a descriptive wedge, not a measured bank margin.

- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
