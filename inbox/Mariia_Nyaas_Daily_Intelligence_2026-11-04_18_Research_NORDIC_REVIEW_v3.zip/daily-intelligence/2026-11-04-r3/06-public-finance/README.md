# Public debt interest sensitivity under an unchanged ECB rate

Standalone GitHub Pages project, published under `daily-intelligence/2026-11-04-r3/06-public-finance/`.

Open `index.html`; data are embedded as displayed native official figures and separately recorded in `data.json`. Three scenario controls are explicitly hypothetical. The Research Intelligence Brief is synchronized with `executive-brief.md` and `methodology.md`.

Source observations were transcribed from the linked official releases. Publication is subject to human review.


## Norwegian evidence

Municipal domestic debt grew 4.4% y/y on a NOK 839 billion stock; rate-sensitivity depends on refinancing structure and budgets, not a mechanically applied policy-rate shock.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
