# Methodology — Rate-decision stability versus refinancing-risk persistence

## Source and reference periods
- Deposit facility rate: 2.5 %, reference 2026-10-29 decision, release 2026-10-29, https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html
- Main refinancing rate: 2.65 %, reference 2026-10-29 decision, release 2026-10-29, https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html
- Marginal lending rate: 2.9 %, reference 2026-10-29 decision, release 2026-10-29, https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html
- Inflation target: 2.0 %, reference medium term, release 2026-10-29, https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html
- Headline HICP expectation, 2026: 3.0 %, reference 2026 forecast, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- Headline HICP expectation, 2027: 2.6 %, reference 2027 forecast, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html

## Derived calculation
2.5 − 2.65 = -0.15 (pp). Difference is descriptive; compare the underlying reference periods and definitions.

## Sensitivity calculation (hypothetical)
`index_points = shock_percent * exposure_percent / 100 * transmission_percent / 100`. This is an illustrative index per 100 reference units. It is NOT an estimated economic relationship. Default shock=3%, exposure=45%, transmission=75%; result=1.0125 index points. Controls: shock 0–10%; exposure 0–100%; transmission 0–200%.

## Research question and causal caution
An unchanged policy decision does not imply unchanged financing conditions or stable refinancing risk.
Mechanisms to investigate: Credit spreads; tenor; refinancing concentration. Leading indicator: refinancing spreads.
Falsification: Narrowing spreads and lengthened maturities would weaken the risk.
No causal identification, time-series model, predictive power, equity valuation, backtest, entity-level accounting conclusion or country-specific transfer coefficient is established. Cross-horizon comparisons are contextual, not matched.

## Review caveats
Eurostat GDP Q3 is preliminary. ECB SPF Q4 2026 is a survey of 52 responses conducted 2–7 October and published 30 October; forecasts are expectations, not realised data. September HICP was published 16 October and is contextual (outside the seven-day release window). Norway-specific risk implications are proposed channels, not directly measured outcomes.


## Independent Norwegian contextual cross-check

Domestic credit stock totals do not establish portfolio concentrations; the difference between corporate and household credit growth is a governance prompt for segment-specific stress limits.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
