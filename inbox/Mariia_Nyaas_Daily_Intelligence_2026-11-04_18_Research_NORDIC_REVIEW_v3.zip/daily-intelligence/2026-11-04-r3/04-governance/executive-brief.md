# Research Intelligence Brief — Rate-decision stability versus refinancing-risk persistence

**Risk & Governance Intelligence · 04 November 2026**

## Central insight
An unchanged policy decision does not imply unchanged financing conditions or stable refinancing risk.

## Five numerical observations / calculations
1. **Deposit facility rate: 2.5 %** (2026-10-29 decision; [ECB_RATE](https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html)).
2. **Main refinancing rate: 2.65 %** (2026-10-29 decision; [ECB_RATE](https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html)).
3. **Marginal lending rate: 2.9 %** (2026-10-29 decision; [ECB_RATE](https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html)).
4. **Inflation target: 2 %** (medium term; [ECB_RATE](https://www.ecb.europa.eu/press/pr/date/2026/html/ecb.mp261029~9a493adf17.en.html)).
5. **Calculated: Deposit facility rate minus Main refinancing rate: -0.15 pp**. 2.5 − 2.65 = -0.15. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Unchanged ECB rates despite tighter financing conditions | Separate denominator, exposure and timing effects. |
| Amplified shock | spread shock and near-term refinancing share increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | Narrowing spreads and lengthened maturities would weaken the risk. |

## What Would Change Our Mind?
Narrowing spreads and lengthened maturities would weaken the risk.

## Practical implication
Review risk limits using market spreads and refinancing calendars, not only policy rates.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

Domestic credit stock totals do not establish portfolio concentrations; the difference between corporate and household credit growth is a governance prompt for segment-specific stress limits.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
