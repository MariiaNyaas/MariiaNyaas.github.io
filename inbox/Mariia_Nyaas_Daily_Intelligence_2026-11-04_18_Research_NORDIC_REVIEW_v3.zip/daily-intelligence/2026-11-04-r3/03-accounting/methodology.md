# Methodology — Inflation forecasts and deferred-tax recoverability risk

## Source and reference periods
- Headline HICP revision, 2026: 0.3 pp, reference Q4 versus Q3 SPF, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- Headline HICP revision, 2027: 0.4 pp, reference Q4 versus Q3 SPF, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- GDP forecast revision, 2026: 0.4 pp, reference Q4 versus Q3 SPF, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- GDP forecast revision, 2027: 0.1 pp, reference Q4 versus Q3 SPF, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- Euro area GDP, Q3 quarter-on-quarter: 0.4 % q/q, reference 2026 Q3 flash, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- EU GDP, Q3 quarter-on-quarter: 0.5 % q/q, reference 2026 Q3 flash, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap

## Derived calculation
0.3 − 0.4 = -0.1 (pp). Difference is descriptive; compare the underlying reference periods and definitions.

## Sensitivity calculation (hypothetical)
`index_points = shock_percent * exposure_percent / 100 * transmission_percent / 100`. This is an illustrative index per 100 reference units. It is NOT an estimated economic relationship. Default shock=3%, exposure=45%, transmission=75%; result=1.0125 index points. Controls: shock 0–10%; exposure 0–100%; transmission 0–200%.

## Research question and causal caution
Revised inflation and growth forecasts can change taxable-profit assumptions, but cannot establish DTA impairment without entity-level forecasts.
Mechanisms to investigate: Margins; real volumes; tax-loss utilisation. Leading indicator: forecast-versus-actual taxable profits.
Falsification: Stable independently evidenced taxable profits would weaken the risk.
No causal identification, time-series model, predictive power, equity valuation, backtest, entity-level accounting conclusion or country-specific transfer coefficient is established. Cross-horizon comparisons are contextual, not matched.

## Review caveats
Eurostat GDP Q3 is preliminary. ECB SPF Q4 2026 is a survey of 52 responses conducted 2–7 October and published 30 October; forecasts are expectations, not realised data. September HICP was published 16 October and is contextual (outside the seven-day release window). Norway-specific risk implications are proposed channels, not directly measured outcomes.


## Independent Norwegian contextual cross-check

A 0.23 percentage-point quarterly increase in the mortgage census rate may raise refinancing sensitivity, but entity-specific going-concern and impairment conclusions require contractual cash-flow evidence.

- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak
- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
