# Research Intelligence Brief — Inflation forecasts and deferred-tax recoverability risk

**Accounting & Audit Intelligence · 04 November 2026**

## Central insight
Revised inflation and growth forecasts can change taxable-profit assumptions, but cannot establish DTA impairment without entity-level forecasts.

## Five numerical observations / calculations
1. **Headline HICP revision, 2026: 0.3 pp** (Q4 versus Q3 SPF; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
2. **Headline HICP revision, 2027: 0.4 pp** (Q4 versus Q3 SPF; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
3. **GDP forecast revision, 2026: 0.4 pp** (Q4 versus Q3 SPF; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
4. **GDP forecast revision, 2027: 0.1 pp** (Q4 versus Q3 SPF; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
5. **Calculated: Headline HICP revision, 2026 minus Headline HICP revision, 2027: -0.1 pp**. 0.3 − 0.4 = -0.1. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Inflation and GDP forecasts revised together | Separate denominator, exposure and timing effects. |
| Amplified shock | inflation assumption error and taxable-profit exposure increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | Stable independently evidenced taxable profits would weaken the risk. |

## What Would Change Our Mind?
Stable independently evidenced taxable profits would weaken the risk.

## Practical implication
Challenge consistency of budgets used for DTA recoverability and impairment testing.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

A 0.23 percentage-point quarterly increase in the mortgage census rate may raise refinancing sensitivity, but entity-specific going-concern and impairment conclusions require contractual cash-flow evidence.

- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak
- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
