# Research Intelligence Brief — The wage-inflation wedge and real purchasing power

**Business & Economic Intelligence · 04 November 2026**

## Central insight
Projected wage growth can exceed headline inflation in one year and not another, altering volume assumptions without predicting consumption.

## Five numerical observations / calculations
1. **Wage growth expectation, 2026: 3.3 %** (2026 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
2. **Headline HICP expectation, 2026: 3 %** (2026 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
3. **Wage growth expectation, 2027: 3.1 %** (2027 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
4. **Headline HICP expectation, 2027: 2.6 %** (2027 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
5. **Calculated: Wage growth expectation, 2026 minus Headline HICP expectation, 2026: 0.3 pp**. 3.3 − 3.0 = 0.3. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | 2026 wage versus inflation expectations | Separate denominator, exposure and timing effects. |
| Amplified shock | real-wage shift and consumer revenue share increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | Household spending decoupling from real wages would weaken the channel. |

## What Would Change Our Mind?
Household spending decoupling from real wages would weaken the channel.

## Practical implication
Scenario-test real wage assumptions against household demand and wage-sensitive costs.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

Corporate domestic credit growth at 5.9% y/y versus household growth of 4.5% may reflect differing funding needs; distinguishing investment finance from working-capital pressure requires company and sector data.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
