# Research Intelligence Brief — Scenario governance when growth and inflation risks diverge

**Risk & Governance Intelligence · 04 November 2026**

## Central insight
A stagflation-style joint shock is not represented by one-dimensional inflation or growth stress tests.

## Five numerical observations / calculations
1. **Headline HICP revision, 2026: 0.3 pp** (Q4 versus Q3 SPF; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
2. **Headline HICP revision, 2027: 0.4 pp** (Q4 versus Q3 SPF; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
3. **GDP forecast revision, 2026: 0.4 pp** (Q4 versus Q3 SPF; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
4. **GDP forecast revision, 2027: 0.1 pp** (Q4 versus Q3 SPF; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
5. **Calculated: Headline HICP revision, 2026 minus Headline HICP revision, 2027: -0.1 pp**. 0.3 − 0.4 = -0.1. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Upside inflation and downside growth risk assessments | Separate denominator, exposure and timing effects. |
| Amplified shock | cost inflation shock and revenue sensitivity increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | Broad-based real earnings improvement would weaken the downside scenario. |

## What Would Change Our Mind?
Broad-based real earnings improvement would weaken the downside scenario.

## Practical implication
Run joint inflation-growth scenarios with independent controls and avoid double-counting.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

Domestic credit stock totals do not establish portfolio concentrations; the difference between corporate and household credit growth is a governance prompt for segment-specific stress limits.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
