# Methodology — Automatic stabilisers under slowing growth and rising unemployment

## Source and reference periods
- Euro area unemployment rate: 6.5 %, reference 2026-09, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp
- Euro area unemployment rate year earlier: 6.3 %, reference 2025-09, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp
- Euro area unemployed persons: 11.555 million, reference 2026-09, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp
- Euro area unemployed annual change: 420 thousand, reference 2026-09 vs 2025-09, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp
- Euro area GDP, Q3 quarter-on-quarter: 0.4 % q/q, reference 2026 Q3 flash, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- EU GDP, Q3 quarter-on-quarter: 0.5 % q/q, reference 2026 Q3 flash, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap

## Derived calculation
6.5 − 6.3 = 0.2 (pp). Difference is descriptive; compare the underlying reference periods and definitions.

## Sensitivity calculation (hypothetical)
`index_points = shock_percent * exposure_percent / 100 * transmission_percent / 100`. This is an illustrative index per 100 reference units. It is NOT an estimated economic relationship. Default shock=3%, exposure=45%, transmission=75%; result=1.0125 index points. Controls: shock 0–10%; exposure 0–100%; transmission 0–200%.

## Research question and causal caution
A deceleration in GDP alongside a higher unemployment stock can pressure both sides of the budget, but no fiscal multiplier is estimated here.
Mechanisms to investigate: Benefits eligibility; tax receipts; spending lag. Leading indicator: benefit claims and VAT receipts.
Falsification: Stable benefit claims and tax receipts would weaken the fiscal stress.
No causal identification, time-series model, predictive power, equity valuation, backtest, entity-level accounting conclusion or country-specific transfer coefficient is established. Cross-horizon comparisons are contextual, not matched.

## Review caveats
Eurostat GDP Q3 is preliminary. ECB SPF Q4 2026 is a survey of 52 responses conducted 2–7 October and published 30 October; forecasts are expectations, not realised data. September HICP was published 16 October and is contextual (outside the seven-day release window). Norway-specific risk implications are proposed channels, not directly measured outcomes.


## Independent Norwegian contextual cross-check

Municipal domestic debt grew 4.4% y/y on a NOK 839 billion stock; rate-sensitivity depends on refinancing structure and budgets, not a mechanically applied policy-rate shock.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
