# Research Intelligence Brief — Automatic stabilisers under slowing growth and rising unemployment

**Public Finance Intelligence · 04 November 2026**

## Central insight
A deceleration in GDP alongside a higher unemployment stock can pressure both sides of the budget, but no fiscal multiplier is estimated here.

## Five numerical observations / calculations
1. **Euro area unemployment rate: 6.5 %** (2026-09; [EU_LABOUR](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp)).
2. **Euro area unemployment rate year earlier: 6.3 %** (2025-09; [EU_LABOUR](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp)).
3. **Euro area unemployed persons: 11.555 million** (2026-09; [EU_LABOUR](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp)).
4. **Euro area unemployed annual change: 420 thousand** (2026-09 vs 2025-09; [EU_LABOUR](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp)).
5. **Calculated: Euro area unemployment rate minus Euro area unemployment rate year earlier: 0.2 pp**. 6.5 − 6.3 = 0.2. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Jobless stock higher year-on-year; GDP momentum lower | Separate denominator, exposure and timing effects. |
| Amplified shock | labour shock and benefit exposure increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | Stable benefit claims and tax receipts would weaken the fiscal stress. |

## What Would Change Our Mind?
Stable benefit claims and tax receipts would weaken the fiscal stress.

## Practical implication
Stress unemployment-related outlays separately from cyclical revenue assumptions.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

Municipal domestic debt grew 4.4% y/y on a NOK 839 billion stock; rate-sensitivity depends on refinancing structure and budgets, not a mechanically applied policy-rate shock.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
