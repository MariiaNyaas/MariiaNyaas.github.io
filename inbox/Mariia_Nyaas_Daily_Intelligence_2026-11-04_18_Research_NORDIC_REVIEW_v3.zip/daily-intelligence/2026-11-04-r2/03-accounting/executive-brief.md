# Research Intelligence Brief — Going-concern headroom under competing policy-rate paths

**Accounting & Audit Intelligence · 04 November 2026**

## Central insight
A modest policy-rate shift can be nonlinear near a covenant boundary; the public rate distribution alone does not measure issuer distress.

## Five numerical observations / calculations
1. **Deposit-rate 2.50% share: 48 % of respondents** (2026 Q4 modal expectations; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
2. **Deposit-rate 2.75% share: 43 % of respondents** (2026 Q4 modal expectations; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
3. **Headline HICP expectation, 2026: 3 %** (2026 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
4. **Headline HICP expectation, 2027: 2.6 %** (2027 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
5. **Calculated: Deposit-rate 2.50% share minus Deposit-rate 2.75% share: 5 pp**. 48.0 − 43.0 = 5.0. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Policy-rate expectation split | Separate denominator, exposure and timing effects. |
| Amplified shock | policy-rate shift and floating debt share increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | Low floating-rate exposure and ample liquidity would invalidate stress relevance. |

## What Would Change Our Mind?
Low floating-rate exposure and ample liquidity would invalidate stress relevance.

## Practical implication
Audit covenant and liquidity sensitivities around the 2.50–2.75% policy-rate alternatives.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

A 0.23 percentage-point quarterly increase in the mortgage census rate may raise refinancing sensitivity, but entity-specific going-concern and impairment conclusions require contractual cash-flow evidence.

- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak
- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
