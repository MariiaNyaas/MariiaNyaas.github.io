# Methodology — Nominal growth resilience against the inflation forecast reset

## Source and reference periods
- GDP growth expectation, 2026: 1.0 %, reference 2026 forecast, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- GDP growth expectation, 2027: 1.3 %, reference 2027 forecast, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- GDP forecast revision, 2026: 0.4 pp, reference Q4 versus Q3 SPF, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- GDP forecast revision, 2027: 0.1 pp, reference Q4 versus Q3 SPF, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- Euro area GDP, Q3 quarter-on-quarter: 0.4 % q/q, reference 2026 Q3 flash, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap
- EU GDP, Q3 quarter-on-quarter: 0.5 % q/q, reference 2026 Q3 flash, release 2026-10-30, https://ec.europa.eu/eurostat/web/products-euro-indicators/w/2-30102026-ap

## Derived calculation
1.0 − 1.3 = -0.3 (pp). Difference is descriptive; compare the underlying reference periods and definitions.

## Sensitivity calculation (hypothetical)
`index_points = shock_percent * exposure_percent / 100 * transmission_percent / 100`. This is an illustrative index per 100 reference units. It is NOT an estimated economic relationship. Default shock=3%, exposure=45%, transmission=75%; result=1.0125 index points. Controls: shock 0–10%; exposure 0–100%; transmission 0–200%.

## Research question and causal caution
Stronger near-term growth forecasts can coexist with higher inflation and therefore ambiguous real cash-flow outcomes.
Mechanisms to investigate: Nominal sales; real volumes; margins. Leading indicator: real earnings revisions.
Falsification: Real earnings growth accelerating without margin pressure would weaken the squeeze.
No causal identification, time-series model, predictive power, equity valuation, backtest, entity-level accounting conclusion or country-specific transfer coefficient is established. Cross-horizon comparisons are contextual, not matched.

## Review caveats
Eurostat GDP Q3 is preliminary. ECB SPF Q4 2026 is a survey of 52 responses conducted 2–7 October and published 30 October; forecasts are expectations, not realised data. September HICP was published 16 October and is contextual (outside the seven-day release window). Norway-specific risk implications are proposed channels, not directly measured outcomes.


## Independent Norwegian contextual cross-check

The 5.35% quarterly mortgage rate and 4.50% policy rate describe different instruments and reference dates; their 0.85 percentage-point difference is a descriptive wedge, not a measured bank margin.

- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
