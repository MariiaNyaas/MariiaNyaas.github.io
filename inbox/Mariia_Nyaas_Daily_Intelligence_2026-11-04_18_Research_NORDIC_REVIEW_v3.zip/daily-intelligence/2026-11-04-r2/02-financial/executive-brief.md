# Research Intelligence Brief — Nominal growth resilience against the inflation forecast reset

**Financial Intelligence · 04 November 2026**

## Central insight
Stronger near-term growth forecasts can coexist with higher inflation and therefore ambiguous real cash-flow outcomes.

## Five numerical observations / calculations
1. **GDP growth expectation, 2026: 1 %** (2026 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
2. **GDP growth expectation, 2027: 1.3 %** (2027 forecast; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
3. **GDP forecast revision, 2026: 0.4 pp** (Q4 versus Q3 SPF; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
4. **GDP forecast revision, 2027: 0.1 pp** (Q4 versus Q3 SPF; [ECB_SPF](https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html)).
5. **Calculated: GDP growth expectation, 2026 minus GDP growth expectation, 2027: -0.3 pp**. 1.0 − 1.3 = -0.3. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Growth forecasts revised up while inflation forecasts also rise | Separate denominator, exposure and timing effects. |
| Amplified shock | nominal revenue impulse and energy-exposed margin increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | Real earnings growth accelerating without margin pressure would weaken the squeeze. |

## What Would Change Our Mind?
Real earnings growth accelerating without margin pressure would weaken the squeeze.

## Practical implication
Separate nominal revenue growth from real volumes and financing costs in valuation assumptions.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

The 5.35% quarterly mortgage rate and 4.50% policy rate describe different instruments and reference dates; their 0.85 percentage-point difference is a descriptive wedge, not a measured bank margin.

- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak
- Norges Bank: Policy rate (released 2026-09-24): https://www.norges-bank.no/en/topics/monetary-policy/policy-rate/

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
