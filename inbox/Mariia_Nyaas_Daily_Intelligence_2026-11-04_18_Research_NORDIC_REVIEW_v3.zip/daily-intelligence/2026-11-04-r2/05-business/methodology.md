# Methodology — Sweden–euro area inflation dispersion and margin strategy

## Source and reference periods
- Sweden headline HICP, September: 1.0 % y/y, reference 2026-09, release 2026-10-16, https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap
- Euro area headline HICP, September: 3.8 % y/y, reference 2026-09, release 2026-10-16, https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap
- Denmark headline HICP, September: 2.1 % y/y, reference 2026-09, release 2026-10-16, https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap
- Euro area headline HICP, August: 3.2 % y/y, reference 2026-08, release 2026-10-16, https://ec.europa.eu/eurostat/en/web/products-euro-indicators/w/2-16102026-ap
- Headline HICP expectation, 2026: 3.0 %, reference 2026 forecast, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html
- Headline HICP expectation, 2027: 2.6 %, reference 2027 forecast, release 2026-10-30, https://www.ecb.europa.eu/stats/ecb_surveys/survey_of_professional_forecasters/html/ecb.spf2026q4.pt.html

## Derived calculation
1.0 − 3.8 = -2.8 (pp). Difference is descriptive; compare the underlying reference periods and definitions.

## Sensitivity calculation (hypothetical)
`index_points = shock_percent * exposure_percent / 100 * transmission_percent / 100`. This is an illustrative index per 100 reference units. It is NOT an estimated economic relationship. Default shock=3%, exposure=45%, transmission=75%; result=1.0125 index points. Controls: shock 0–10%; exposure 0–100%; transmission 0–200%.

## Research question and causal caution
A wide cross-border inflation gap creates pricing and procurement asymmetry, not automatic arbitrage.
Mechanisms to investigate: Input geography; FX; customer pass-through. Leading indicator: local input-cost inflation.
Falsification: FX and supplier repricing offsetting the gap would invalidate the advantage.
No causal identification, time-series model, predictive power, equity valuation, backtest, entity-level accounting conclusion or country-specific transfer coefficient is established. Cross-horizon comparisons are contextual, not matched.

## Review caveats
Eurostat GDP Q3 is preliminary. ECB SPF Q4 2026 is a survey of 52 responses conducted 2–7 October and published 30 October; forecasts are expectations, not realised data. September HICP was published 16 October and is contextual (outside the seven-day release window). Norway-specific risk implications are proposed channels, not directly measured outcomes.


## Independent Norwegian contextual cross-check

Corporate domestic credit growth at 5.9% y/y versus household growth of 4.5% may reflect differing funding needs; distinguishing investment finance from working-capital pressure requires company and sector data.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
