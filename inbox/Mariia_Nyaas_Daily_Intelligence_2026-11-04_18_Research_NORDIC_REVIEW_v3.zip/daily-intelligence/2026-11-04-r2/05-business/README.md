# Sweden–euro area inflation dispersion and margin strategy

Standalone GitHub Pages project, published under `daily-intelligence/2026-11-04-r2/05-business/`.

Open `index.html`; data are embedded as displayed native official figures and separately recorded in `data.json`. Three scenario controls are explicitly hypothetical. The Research Intelligence Brief is synchronized with `executive-brief.md` and `methodology.md`.

Source observations were transcribed from the linked official releases. Publication is subject to human review.


## Norwegian evidence

Corporate domestic credit growth at 5.9% y/y versus household growth of 4.5% may reflect differing funding needs; distinguishing investment finance from working-capital pressure requires company and sector data.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
