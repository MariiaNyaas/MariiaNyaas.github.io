# Research Intelligence Brief — The youth-labour shock as an unsecured-credit early signal

**Credit Risk Intelligence · 04 November 2026**

## Central insight
Youth unemployment is a potentially earlier household cash-flow stress channel than the aggregate jobless rate, not a validated default predictor.

## Five numerical observations / calculations
1. **Euro area youth unemployment rate: 15.4 %** (2026-09; [EU_LABOUR](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp)).
2. **Euro area youth unemployment rate previous month: 15.1 %** (2026-08; [EU_LABOUR](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp)).
3. **EU youth unemployment rate: 15.5 %** (2026-09; [EU_LABOUR](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp)).
4. **EU youth unemployment rate previous month: 15.4 %** (2026-08; [EU_LABOUR](https://ec.europa.eu/eurostat/web/products-euro-indicators/w/3-30102026-bp)).
5. **Calculated: Euro area youth unemployment rate minus Euro area youth unemployment rate previous month: 0.3 pp**. 15.4 − 15.1 = 0.3. Difference is descriptive; compare the underlying reference periods and definitions.

## Investor / Decision Matrix
| Pattern | Interpretation to investigate | Additional evidence |
|---|---|---|
| Observed macro signal | Youth unemployment rising faster than headline | Separate denominator, exposure and timing effects. |
| Amplified shock | youth labour stress and young-borrower share increase simultaneously | Test entity-level exposures and observed pass-through. |
| Resilient countercase | The transmission channel does not materialise | Stable arrears among young cohorts would weaken the transmission mechanism. |

## What Would Change Our Mind?
Stable arrears among young cohorts would weaken the transmission mechanism.

## Practical implication
Segment new-to-credit borrowers separately and test payment behaviour before policy changes.

**Caveat:** Survey forecasts are not realised observations; the illustrative transmission sensitivity is not empirically estimated.


## Independent Norwegian evidence and interpretation

Household credit growth slowed to 4.5% y/y while corporate credit growth reached 5.9%; portfolio-wide PD overlays should distinguish borrower segments and verify arrears rather than infer a single stress direction.

- Statistics Norway: Domestic credit, September 2026 (released 2026-10-28): https://www.ssb.no/bank-og-finansmarked/finansielle-indikatorer/statistikk/kredittindikator/artikler/innenlandsk-gjeld
- Statistics Norway: Interest rates in banks and mortgage companies (released 2026-10-29): https://www.ssb.no/en/bank-og-finansmarked/finansinstitusjoner-og-andre-finansielle-foretak/statistikk/renter-i-banker-og-kredittforetak

Observations and their exact reference periods are recorded in `data.json` under `norway_cross_check`. These observations do not prove the hypothesised transmission mechanism.
